CREATE DEFINER=`root`@`localhost` PROCEDURE `stp_QuizGetUserDetail`(

                in V_nRequestType int,

    in V_sFirstName varchar(100),

    in V_sLastName varchar(100),

    in V_sUsername varchar(50) ,

    in V_sEmailId varchar(100),

    in V_sMobileNumber varchar(15),

    in V_sPassword varchar(200),

    in V_nRoleId int,

    in V_nCreatedBy int,

    in V_nCenterId int,

    in V_sSystemInfo varchar(2000)

)
label : BEGIN

declare V_nUserId int;

declare V_nRole int;

 

 

set V_nRole=(select nRoleId from tbl_qusermaster where sUserName=V_sUsername and sPassword=V_sPassword and V_nRequestType<>3);

 

 

if( V_sPassword is null or V_sPassword='' or V_sUsername is null or V_sUsername='' ) then

                select 'Please give username and password' as Error_msg;

    leave label;

else

    if(V_nRequestType=3) then

                                if( V_nCenterId is null or V_nCreatedBy is null or V_nRoleId is null or V_sMobileNumber is null or V_sMobileNumber='' or V_sFirstName is null or V_sFirstName ='' ) then

                                                select 'Please provide all compulsary values' as Error_msg;

                                                leave label;

        end if;

                                insert into tbl_qusermaster

                                (

                                                nRoleId,

                                                sFirstName,

                                                sLastName,

                                                sMobileNumber,

                                                sEmailId ,

                                                sUsername,

                                                sPassword,

                                                dCreatedOn,

            nCreatedBy,

                                                nCenterId

                                )

                                values

                                (

                                                V_nRoleId,

                                                V_sFirstName,

                                                V_sLastName,

                                                V_sMobileNumber,

                                                V_sEmailId,

                                                V_sUsername,

                                                V_sPassword,

                                                now(),

            V_nCreatedBy,

                                                V_nCenterId

                                );

                                set V_nUserId=(select last_insert_id());

 

                                insert into tbl_qusercentermapping(       nUserId,nCenterId) select V_nUserId, V_nCenterId;

                                end if;

       

Update tbl_qusermaster set

                sSystemInfo=V_sSystemInfo,

    dLoginTime=now()

    where sUsername = V_sUsername

        AND sPassword = V_sPassword

                                                and nRoleId=if(V_nRequestType=3,V_nRoleId,V_nRole);

       

SELECT

    qu.nUserId,

    qu.nRoleId,

    qu.sFirstName,

    qu.sLastName,

    qu.sMobileNumber,

    qu.sEmailId,

    qu.sUsername,

    qu.sPassword,

    qu.bIsActive,

    qu.nCreatedBy,

    qu.dCreatedOn,

    qu.dLoginTime,

    qu.bStatus,

    qu.dTotalTimeEscape,

    qu.nlastQuestionId,

    qu.sSystemInfo,

    qu.nCenterId,
    qu.nTestId,

    if(qu.nCenterId=0,'No Center',(select qc.sCenterName from tbl_qcenter qc where qc.nCenterId=qu.nCenterId) ) as sCenterName

FROM tbl_qusermaster qu

WHERE

    qu.sUsername = V_sUsername

        AND qu.sPassword = V_sPassword

                                                and qu.nRoleId=if(V_nRequestType=3,V_nRoleId,V_nRole);

 

insert into tbl_qusermaster_log

(

                nUserId,

                sName ,

                sMobileNumber ,

                sUsername ,

                dLoginTime ,

    sSystemInfo

)

select

                nUserId,

                concat(ifnull(sFirstName,' '),' ',ifnull(sLastName,' ')) as sName ,

                sMobileNumber,

                V_sUsername ,

                now() ,

    sSystemInfo

from tbl_qusermaster

                where sUsername=V_sUsername and sPassword=V_sPassword;

end if;

 

END