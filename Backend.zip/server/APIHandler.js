const FILE_NAME = ' APIHandler.js ';
const DBConnection = require('./DBOperations/MySQLOperations'); //Database operations 
const global = require('./global.js');
const md5 = require('md5');
const moment = require('moment');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const multer = require('multer');
const path = require('path');
const async = require('async');

// function test(){
//     var query= `CALL stp_QuizAddUpdateCenter( 1,'MUM','Andheri','63Moons','Sanket','8828381442',1,'AnuGupta');`
//     DBConnection.executequery(query).then(function (resp) {
//         console.log(resp);
//     }).catch(function (err) {
//         console.log(err);
//     });
// }
// test();
module.exports = {
    test: (request, response) => {
        var temp = 1;
        var query = `CALL stp_QuizAddUpdateCenter(${temp});`;
        console.log(request.connection);
        console.log(query);
        response.send(query);
    },
    userLogin: (request, response) => {
        const FUNC_NAME = " userLogin() ";
        var responseData = {};
        responseData.status = 1;
        try {
            if (request.body.loginId && request.body.password) {
                var sPassword = md5(global.SALT + request.body.password);
                var sFirstName = request.body.fname || "";
                var sLastName = request.body.lname || "";
                var sUserName = request.body.loginId || "";
                var sEmailId = request.body.email || "";
                var sContactNumber = request.body.cnumber || "";
                var nRequestType = request.body.requesttype || "";
                var nRoleId = 0;
                var sCenterCode = 0;
                var nTestCreatedId = 0;
                if (nRequestType == 3) {
                    sCenterCode = request.body.centercode;
                    nRoleId = 2;
                    nTestCreatedId = request.body.testid;
                }
                var sSystemInfo = request.connection.remoteAddress;
                // var SystemInfo = JSON.stringify(sSystemInfo);
                var query = `CALL stp_QuizGetUserDetail(${nRequestType},'${sFirstName}','${sLastName}','${sUserName}','${sEmailId}','${sContactNumber}','${sPassword}',${nRoleId},0,${sCenterCode},'${sSystemInfo}',${nTestCreatedId});`;
                console.log(query);
                DBConnection.executequery(query).then(function (resp) {
                    if (resp[0] != undefined && resp[0][0].bIsActive[0] == 0) {
                        var userData = resp[0][0];
                        if (userData != undefined && userData.sPassword == sPassword) {
                            var currntdatetime = moment(new Date()).format("YYYYMMDDHHmmssms");
                            var sessionID = sUserName + currntdatetime + global.SALT;
                            sessionID = md5(sessionID);
                            var expiresIn = global.getElapsedTime();
                            var sJWTBody = {};
                            sJWTBody.nCenterId = userData.nCenterId;
                            sJWTBody.sUsername = userData.sUsername;
                            sJWTBody.nUserId = userData.nUserId;
                            sJWTBody.nRoleId = userData.nRoleId;
                            sJWTBody.TestId = userData.nTestId;
                            var jwtToken = jwt.sign(sJWTBody, global.JWT_SECRET, { expiresIn: expiresIn });
                            responseData.jwtToken = jwtToken;
                            global.jwtTokens.push(jwtToken);
                            responseData.sessionId = sessionID;
                            global.session[sessionID] = userData.nUserName;
                            responseData.LoginStatus = userData.bStatus[0];
                            responseData.TestId = userData.nTestId;
                            responseData.IsActive = userData.bIsActive[0];
                            responseData.CreatedOn = userData.dCreatedOn;
                            responseData.LoginTime = userData.dLoginTime;
                            responseData.TotalTimeEscape = userData.dTotalTimeEscape;
                            responseData.CenterId = userData.nCenterId;
                            responseData.CreatedBy = userData.nCreatedBy;
                            responseData.lastQuestionId = userData.nlastQuestionId;
                            responseData.RoleId = userData.nRoleId;
                            responseData.UserId = userData.nUserId;
                            responseData.EmailId = userData.sEmailId;
                            responseData.FirstName = userData.sFirstName;
                            responseData.LastName = userData.sLastName;
                            responseData.MobileNumber = userData.sMobileNumber;
                            responseData.SystemInfo = userData.sSystemInfo;
                            responseData.Username = userData.sUsername;
                        } else {
                            responseData.status = -1;
                            responseData.message = "Unauthorized";
                            response.status(200).send(responseData);
                        }
                    } else {
                        responseData.status = -1;
                        responseData.message = "Unauthorized";
                        response.status(200).send(responseData);
                    }
                    responseData.message = "Login Successful";
                    response.status(200).send(responseData);
                }).catch(function (err) {
                    global.errorLogging(err.message + FUNC_NAME);
                    responseData.message = "Query Failed ";
                    responseData.status = -1;
                    response.status(500).send(responseData);
                });
            }
        } catch (err) {
            responseData.status = -1;
            responseData.message = "something went wrong while login, Please try again.";
            response.status(500).send(responseData);
            global.errorLogging(err.message + FUNC_NAME);
        }
    },
    userLogout: (request, response) => {
        const FUNC_NAME = " userLogout() ";
        var responseData = {};
        responseData.status = 1;
        try {
            var sessionId = request.body.sessionId;
            if (sessionId != undefined) {
                delete global.session[sessionId];
            }
            var jwtToken = request.headers.authorization;
            var nIndex = global.jwtTokens.indexOf(jwtToken);
            if (nIndex >= 0) {
                global.jwtTokens.splice(nIndex, 1);
            }
            responseData.message = "Successfully logged out."
            response.status(200).send(responseData);
        } catch (err) {
            responseData.status = -1;
            responseData.message = "something went wrong while logout, Please try again.";
            response.status(500).send(responseData);
            global.errorLogging(err.message + FUNC_NAME);
        }
    },
    fileupload: function (request, response) {
        const FUNC_NAME = " uploadFile() ";
        var responseData = {};
        responseData.status = 1;
        responseData.message = "File uploaded successfully.";
        try {
            var directory = "";
            var orignalFileName = "";
            var systemFileName = "";
            var userName = 0;
            var jwtToken = request.headers.authorization;
            var storage = multer.diskStorage({
                destination: function (req, file, callback) {
                    directory = global.config.server.fileuploadpath;
                    if (!fs.existsSync(directory)) {
                        fs.mkdirSync(directory);
                    }
                    directory = path.join(directory, moment(new Date()).format("YYYYMMDD"));
                    if (!fs.existsSync(directory)) {
                        fs.mkdirSync(directory);
                    }
                    callback(null, directory);
                },
                filename: function (req, file, callback) {
                    orignalFileName = file.originalname;
                    fileString = req.body.fileString;
                    var fileNameparts = orignalFileName.split(".");
                    if (fileNameparts[fileNameparts.length - 1] != 'csv') {
                        responseData.status = -1;
                        responseData.message = "File not supported.";
                        response.status(400).send(responseData);
                        return;
                    }
                    systemFileName = fileNameparts[0] + "_" + moment(new Date()).format("YYYYMMDDHHmmssms") + "." + fileNameparts[1];
                    callback(null, systemFileName);
                }
            });
            // finally Uploading File
            var upload = multer({ storage: storage }).single('file');
            upload(request, response, function (err) {
                if (err) {
                    responseData.status = -1;
                    responseData.message = "Failed to upload the file. Please try again.";
                    return response.status(500).send(responseData);
                }
                var filePath = path.join(directory, systemFileName);
                async.waterfall([
                    function tuncateTempTable(callback) {
                        var query = "";
                        query = "truncate tbl_quploadmaster;"
                        DBConnection.executequery(query).then(function (resp) {
                            callback(null);
                        }).catch(function (err) {
                            global.errorLogging(err.message + FUNC_NAME);
                            callback("Failed to tuncate temp table.");
                            return;
                        });
                    },
                    function loadData(callback) {
                        var query = "";
                        // query = "LOAD DATA LOCAL INFILE '" + filePath + "' INTO TABLE tbl_TempQuizUploadMaster ignore 1 lines  (sData) set nLineNumber = null ;";
                        query = "LOAD DATA LOCAL INFILE '" + filePath + "' INTO TABLE tbl_quploadmaster (sData);";
                        DBConnection.executequery(query).then(function (resp) {
                            callback(null);
                        }).catch(function (err) {
                            global.errorLogging(err.message + FUNC_NAME);
                            callback("Failed to load data.");
                            return;
                        });
                    },
                    function processData(callback) {
                        userName = req.loginInfo[global.userName];
                        var decode = jwt.verify(jwtToken, global.JWT_SECRET);
                        var centerID = decode.nCenterId;
                        var query = `CALL stp_QuizUploadMaster(${userName} , ${centerID});`;
                        DBConnection.executequery(query).then(function (resp) {
                            if (resp[0] != undefined && resp[0][0] != undefined && resp[0][0].Error_String != undefined) {
                                global.errorLogging(resp[0][0].Error_String + FUNC_NAME);
                                callback("Failed to process data.");
                                return;
                            } else {
                                callback(null);
                            }
                        }).catch(function (err) {
                            global.errorLogging(err.message + FUNC_NAME);
                            callback("Failed to process data.");
                            return;
                        });
                    }
                ], function finalCallbeck(err, result) {
                    if (err == null) {
                        responseData.status = 1;
                        response.send(responseData);
                    } else {
                        responseData.status = -1;
                        responseData.message = err;
                        response.status(503).send(responseData);
                    }
                });
            });
        } catch (err) {
            global.errorLogging(err.message + FUNC_NAME);
            responseData.statuscode = -1;
            responseData.errorstring = "Something went wrong while uploading the file. Please try again.";
            response.status(500).send(responseData);
        }
    },
    addUpdateCenter: (request, response) => {
        const FUNC_NAME = " addUpdateCenter()";
        var responseData = {};
        responseData.status = 1;
        try {
            var nCenterId = request.body.CenterId;
            var sCenterCode = request.body.CenterCode;
            var sCenterName = request.body.CenterName;
            var sCenterAddress = request.body.CenterAddress;
            var sContactPerson = request.body.ContactPerson;
            var sContactNumber = request.body.ContactNumber;
            var bIsActive = request.body.IsActive || 1;
            var jwtToken = request.headers.authorization;
            var sCreatedBy = "";
            if (jwtToken) {
                var decode = jwt.verify(jwtToken, global.JWT_SECRET);
                sCreatedBy = decode.nUserId;
                var query = `CALL stp_QuizAddUpdateCenter( ${nCenterId},'${sCenterCode}','${sCenterName}','${sCenterAddress}','${sContactPerson}','${sContactNumber}',${bIsActive},'${sCreatedBy}');`;
                // console.log(query);
                DBConnection.executequery(query).then(function (resp) {
                    responseData.data = resp;
                    response.status(200).send(responseData);
                }).catch(function (err) {
                    global.errorLogging(err.message + FUNC_NAME);
                    response.status(503).send(null);
                });
            } else {
                responseData.status = -1;
                responseData.message = "Invalid request, Please try again.";
                response.status(503).send(responseData);
                global.errorLogging(responseData.message + FUNC_NAME);
            }

        } catch (err) {
            responseData.status = -1;
            responseData.message = "something went wrong while logout, Please try again.";
            response.status(500).send(responseData);
            global.errorLogging(err.message + FUNC_NAME);
        }
    },
    getCenterList: (request, response) => {
        const FUNC_NAME = " getCenterList() ";
        var responseData = {};
        responseData.status = 1;
        try {
            var query = `CALL stp_QuizGetCenterList();`;
            // console.log(query);
            DBConnection.executequery(query).then(function (resp) {
                if (resp && resp[0]) {
                    responseData.data = resp[0];
                    response.status(200).send(responseData);
                } else {
                    responseData.status = -1;
                    responseData.message = "something went wrong while geting center, Please try again.";
                    response.status(500).send(responseData);
                    global.errorLogging(responseData.message + FUNC_NAME);
                }
            }).catch(function (err) {
                responseData.status = -1
                responseData.message = err.message;
                global.errorLogging(err.message + FUNC_NAME);
                response.status(503).send(responseData);
            });
        } catch (err) {
            responseData.status = -1;
            responseData.message = "something went wrong while getting center list, Please try again.";
            response.status(500).send(responseData);
            global.errorLogging(err.message + FUNC_NAME);
        }
    },
    getSectionList: (request, response) => {
        const FUNC_NAME = " getCenterList() ";
        var responseData = {};
        responseData.status = 1;
        try {
            var query = `CALL stp_QuizGetSectionList();`;
            // console.log(query);
            DBConnection.executequery(query).then(function (resp) {
                if (resp && resp[0]) {
                    responseData.data = resp[0];
                    response.status(200).send(responseData);
                } else {
                    responseData.status = -1;
                    responseData.message = "something went wrong while geting Sections, Please try again.";
                    response.status(500).send(responseData);
                    global.errorLogging(responseData.message + FUNC_NAME);
                }
            }).catch(function (err) {
                global.errorLogging(err.message + FUNC_NAME);
                response.status(503).send(null);
            });
        } catch (err) {
            responseData.status = -1;
            responseData.message = "something went wrong while geting Sections, Please try again.";
            response.status(500).send(responseData);
            global.errorLogging(err.message + FUNC_NAME);
        }
    },
    fileread: function (request, response) {
        const FUNC_NAME = " readFile() ";
        var responseData = {};
        responseData.status = 1;
        responseData.message = "File reading successfully.";
        try {
            var directory = "";
            var orignalFileName = "";
            var systemFileName = "";
            var userName = "";
            var nSectionId = "";
            var storage = multer.diskStorage({
                destination: function (req, file, callback) {
                    directory = global.config.server.fileuploadpath;
                    if (!fs.existsSync(directory)) {
                        fs.mkdirSync(directory);
                    }
                    directory = path.join(directory, moment(new Date()).format("YYYYMMDD"));
                    if (!fs.existsSync(directory)) {
                        fs.mkdirSync(directory);
                    }
                    callback(null, directory);
                },
                filename: function (req, file, callback) {
                    userName = req.loginInfo["sUsername"];
                    orignalFileName = file.originalname;
                    // fileString = req.body.fileString;
                    nSectionId = req.body.sectionid;
                    var fileNameparts = orignalFileName.split(".");
                    if (fileNameparts[fileNameparts.length - 1] != 'json') {
                        responseData.status = -1;
                        responseData.message = "File not supported.";
                        response.status(400).send(responseData);
                        return;
                    }
                    systemFileName = fileNameparts[0] + "_" + moment(new Date()).format("YYYYMMDDHHmmssms") + "." + fileNameparts[1];
                    callback(null, systemFileName, nSectionId);
                }
            });
            // finally Uploading File
            var upload = multer({ storage: storage }).single('file');
            upload(request, response, function (err) {
                if (err) {
                    responseData.status = -1;
                    responseData.message = "Failed to read the file. Please try again.";
                    return response.status(500).send(responseData);
                }
                var filePath = path.join(directory, systemFileName);
                async.waterfall([
                    function readingTable(callback) {
                        var sStringData = fs.readFileSync(filePath, "utf8");
                        var data = JSON.parse(sStringData);
                        for (var i = 0; i < data.questions.length; i++) {
                            var nCorrectOption = "";
                            var nId = 0;
                            var nQuestionId = data.questions[i].id;
                            var nQuestionTypeId = data.questions[i].questionTypeId;
                            var sOptions = data.questions[i].options;
                            for (var j = 0; j < data.questions[i].options.length; j++) {
                                if (data.questions[i].options[j].isAnswer == true) {
                                    data.questions[i].options[j].isAnswer = false
                                    nCorrectOption = data.questions[i].options[j].id;
                                    break;
                                }
                            }
                            var sIsActive = data.questions[i].questionType.isActive;
                            var sQuestionName = data.questions[i].name;
                            // var nSectionId = request.body.sectionid;
                            var token = request.headers.authorization;
                            if (token == undefined) {
                                fs.appendFile(global.jwtAuthCheckLog, JSON.stringify(logData) + "\n", function (err) {
                                    if (err) global.errorLogging(err.message + FUNC_NAME);;
                                });
                                responseData.message = "Authentication Failed.";
                                return res.status(401).json(responseData);
                            }
                            var decode = jwt.verify(token, global.JWT_SECRET);
                            var sCreatedBy = decode.nUserId;

                            var query = `CALL stp_QuizAddUpdateQuestion( ${nId},${nSectionId},${nQuestionId},${nQuestionTypeId},'${sQuestionName}','${sOptions}','${nCorrectOption}',${sIsActive},'${sCreatedBy}');`;
                            DBConnection.executequery(query).then(function (resp) {
                                callback(null);
                            }).catch(function (err) {
                                global.errorLogging(err.message + FUNC_NAME);
                                callback("Query Failed ");
                                return;
                            });
                        }
                    },
                ], function finalCallbeck(err, result) {
                    if (err == null) {
                        responseData.status = 1;
                        response.send(responseData);
                    } else {
                        responseData.status = -1;
                        responseData.message = err;
                        if (responseData.errors.length > 0) {
                            response.status(200).send(responseData);
                        } else {
                            response.status(503).send(responseData);
                        }
                    }
                });
            });
        } catch (err) {
            global.errorLogging(err.message + FUNC_NAME);
            responseData.statuscode = -1;
            responseData.errorstring = "Something went wrong while uploading the file. Please try again.";
            response.status(500).send(responseData);
        }
    },
    addUpdateSection: (request, response) => {
        const FUNC_NAME = " addUpdateSection() ";
        var responseData = {};
        responseData.status = 1;
        try {
            var nSectionId = request.body.SectionId;
            //var sSectionCode = request.body.SectionCode;
            var sSectionName = request.body.SectionName;
            var sDescription = request.body.Description || "";
            var bIsActive = request.body.IsActive || 1;
            // var sCreatedBy = request.body.CreatedBy;
            var jwtToken = request.headers.authorization;
            var nCreatedBy = "";
            if (jwtToken && sSectionName && bIsActive) {
                var decode = jwt.verify(jwtToken, global.JWT_SECRET);
                nCreatedBy = decode.nUserId;
                var query = `CALL stp_QuizAddUpdateSection( ${nSectionId},'${sSectionName}','${sDescription}',${bIsActive},${nCreatedBy});`;
                // console.log(query);
                DBConnection.executequery(query).then(function (resp) {
                    responseData.data = resp;
                    response.status(200).send(responseData);
                }).catch(function (err) {
                    global.errorLogging(err.message + FUNC_NAME);
                    response.status(503).send(null);
                });
            }
        } catch (err) {
            responseData.status = -1;
            responseData.message = "something went wrong while logout, Please try again.";
            response.status(500).send(responseData);
            global.errorLogging(err.message + FUNC_NAME);
        }
    },
    addUpdateExam: (request, response) => {
        const FUNC_NAME = " AddUpdateExam() ";
        var responseData = {};
        responseData.status = 1;
        try {
            var nTestCreatedId = request.body.TestCreatedId;
            var sTestName = request.body.TestName;
            var nCenterId = request.body.CenterId;
            var sSectionId = request.body.SectionId;
            var nMCQQuestion = 0 /*request.body.MCQQuestion*/;
            var nProgrammingQuestion = request.body.ProgrammingQuestion || 0;
            var nTotalQuestions = 0;/*request.body.TotalQuestions;*/
            var dTotalExamTime = request.body.TotalExamTime;
            var bIsActive = request.body.IsActive || 1;
            var sDescription = request.body.Description || "";
            var sTestDifficultyLevel = request.body.difficultylevel || "1";
            var sQuestionsPerSection = request.body.questionspersection
            var jwtToken = request.headers.authorization;
            var nCreatedBy = "";
            // nProgrammingQuestion && && nTestCreatedId && nMCQQuestion
            if (jwtToken && sTestName && nCenterId && sSectionId && dTotalExamTime && sTestDifficultyLevel && sQuestionsPerSection) {
                var arrquestionspersection = sQuestionsPerSection.split(',');
                for (var i = 0; i < arrquestionspersection.length; i++) {
                    nMCQQuestion = nMCQQuestion + parseInt(arrquestionspersection[i]);
                }
                nTotalQuestions = nMCQQuestion + parseInt(nProgrammingQuestion);
                var decode = jwt.verify(jwtToken, global.JWT_SECRET);
                nCreatedBy = decode.nUserId;
                var query = `CALL stp_QuizAddUpdateExam( ${nTestCreatedId},'${sTestName}',${nCenterId},'${sSectionId}',${nMCQQuestion},${nProgrammingQuestion},'${nTotalQuestions}',${dTotalExamTime},${bIsActive},'${sDescription}','${nCreatedBy}','${sTestDifficultyLevel}','${sQuestionsPerSection}');`;
                DBConnection.executequery(query).then(function (resp) {
                    if (resp && resp[0] && resp[0][0]) {
                        responseData.data = resp[0][0];
                        response.status(200).send(responseData);
                    }
                    else {
                        responseData.status = -1;
                        responseData.message = "something went wrong while adding exam, Please try again.";
                        response.status(503).send(responseData);
                    }
                }).catch(function (err) {
                    global.errorLogging(err.message + FUNC_NAME);
                    response.status(503).send(null);
                });
            }
        } catch (err) {
            responseData.status = -1;
            responseData.message = "something went wrong while adding exam, Please try again.";
            response.status(500).send(responseData);
            global.errorLogging(err.message + FUNC_NAME);
        }
    },
    startExam: (request, response) => {
        const FUNC_NAME = " startExam() ";
        var responseData = {};
        responseData.status = 1;
        try {
            var query = `CALL stp_QuizGetQuestionsPerSection('${request.body.examID}');`;
            DBConnection.executequery(query).then(function (resp) {

                if (resp && resp[0] && resp[0][0]) {
                    var arrSectionWiseQuestionIds = resp[0][0].sSectionWiseQuestionIds.split('|');
                    var arrTotalSectionIds = resp[0][0].sSectionIds.split(',');
                    var arrTotalSectionNames = resp[0][0].sSectionName.split(',');
                    var arrTotalSectionQuestions = resp[0][0].sTotalSectionQuestions.split(',');
                    // var nTotalRandomNumber = (resp[0][0].nMCQQuestion / arrTotalSectionIds.length);
                    var nTotalRandomNumber = resp[0][0].sQuestionsPerSection.split(',');
                    var arrSection = [];
                    for (var i = 0; i < arrTotalSectionIds.length; i++) {
                        var objSection = {};
                        generateRandomNumbers(nTotalRandomNumber, arrTotalSectionQuestions[i], arrSectionWiseQuestionIds[i], (err, resp) => {
                            objSection.sectionId = arrTotalSectionIds[i];
                            objSection.sectionName = arrTotalSectionNames[i];
                            objSection.questionIds = '{' + resp + '}';
                            arrSection.push(objSection);
                        });
                    }
                    responseData.sections = arrSection;
                    response.status(200).send(responseData);
                } else {
                    global.errorLogging(err.message + FUNC_NAME);
                    responseData.message = "Query Failed ";
                    responseData.status = -1;
                    response.status(500).send(responseData);
                }
            }).catch(function (err) {
                global.errorLogging(err.message + FUNC_NAME);
                responseData.message = "Query Failed ";
                responseData.status = -1;
                response.status(500).send(responseData);
            });
        } catch (error) {
            responseData.status = -1;
            responseData.message = "something went wrong while starting exam, Please try again.";
            response.status(500).send(responseData);
            global.errorLogging(err.message + FUNC_NAME);
        }
    },
    addUpdateUser: (request, response) => {
        const FUNC_NAME = " addUpdateUser() ";
        var responseData = {};
        responseData.status = 1;
        try {
            if (request.body.roleid && request.body.uid && request.body.fname && request.body.password && request.body.cname && request.body.cnumber && request.body.email) {
                var nUserId = request.body.uid;
                var nRoleId = request.body.roleid;
                var bIsActive = 1;
                var sFirstName = request.body.fname;
                var sLastName = request.body.lname;
                var sUserName = request.body.uname;
                var sEmailId = request.body.email;
                var sContactNumber = request.body.cnumber;
                var sPassword = md5(global.SALT + request.body.password);
                var nCenterId = request.body.cname;
                var nStudentStatus = request.body.bstatus;
                var jwtToken = request.headers.authorization;
                var nCreatedBy = "";
                if (jwtToken) {
                    var decode = jwt.verify(jwtToken, global.JWT_SECRET);
                    nCreatedBy = decode.nUserId;
                    nTestCreatedId = decode.TestId;
                    var query = `call stp_QuizAddUpdateUser(${nUserId},${nRoleId},'${sFirstName}','${sLastName}','${sContactNumber}','${sEmailId}','${sUserName}','${sPassword}',${bIsActive},${nCreatedBy},${nCenterId},${nTestCreatedId});`;
                    DBConnection.executequery(query).then(function (resp) {
                        if (resp && resp[0] && resp[0][0]) {
                            if (nRoleId == 2) {
                                var curtime = moment(new Date()).format("HH:mm:ss");
                                startExam(resp[0][0].nExamId, nUserId, curtime, nStudentStatus, (functionError, examdetails) => {
                                    if (functionError) {
                                        responseData.status = -1;
                                        responseData.message = 'something went wrong while getting details'
                                        response.status(500).send(responseData);
                                    } else {
                                        responseData.status = 1;
                                        responseData.message = examdetails;
                                        response.status(200).send(responseData);
                                    }
                                })
                            }
                            else {
                                responseData.status = 1;
                                responseData.message = resp;
                                response.status(200).send(responseData);
                            }
                        } else {
                            responseData.status = -1;
                            responseData.message = "Query Failed ";
                            response.status(500).send(responseData);
                        }
                    }).catch(function (err) {
                        responseData.status = -1;
                        responseData.message = "Query Failed ";
                        response.status(500).send(responseData);
                    });
                }
            } else {
                responseData.status = -1;
                responseData.message = "Incomplete data. Please try again";
                response.status(400).send(responseData);
            }
        } catch (error) {
            responseData.status = -1;
            responseData.message = "something went wrong while starting exam, Please try again.";
            response.status(500).send(responseData);
            global.errorLogging(err.message + FUNC_NAME);
        }

    },
    getSectionWiseQuestions: (request, response) => {
        const FUNC_NAME = " getSectionWiseQuestions() ";
        var responseData = {};
        var questions = [];
        responseData.status = 1;
        try {
            var jwtToken = request.headers.authorization;
            if (request.body.testid && request.body.questionid && jwtToken) {
                var decode = jwt.verify(jwtToken, global.JWT_SECRET);
                var userid = decode.nUserId;
                // var userid = 1;
                var nRequestType = 2; // Get the data 
                var questionids = (request.body.questionid.split('{')[1]).split('}')[0];
                var query = `CALL stp_QuizGetRandomQuestion(2,${userid},${request.body.testid},'${questionids}','');`;
                DBConnection.executequery(query).then(function (resp) {
                    if (resp && resp[0]) {
                        // console.log(resp);
                        for (var i = 0; i < resp[0].length; i++) {
                            console.log(resp[0][i]);
                            var objquestions = {};
                            objquestions.question = resp[0][i].sQuestion;
                            // objquestions.options = resp[0][i].sOptions;
                            var options = resp[0][i].sOptions.split(',');
                            var arroptions = [];
                            // questions.id = nTestCreatedId;
                            // questions.name = sTestName;
                            // questions.description = sDescription;
                            for (var j = 0; j < options.length; j++) {
                                arroptions.push(options[j]);
                            }
                            objquestions.options = arroptions;
                            objquestions.questionid = resp[0][i].nQuestionId;
                            objquestions.sectionid = resp[0][i].nSectionId;
                            objquestions.sectionname = resp[0][i].sSectionName;
                            objquestions.questiontypeid = resp[0][i].nQuestionTypeId;
                            objquestions.questiontypename = resp[0][i].sQuestionTypeName;
                            objquestions.studentselectedanswer = resp[0][i].sAnswer;
                            questions.push(objquestions);
                        }
                        responseData.question = questions;
                        response.status(200).send(responseData);
                    } else {
                        global.errorLogging(err.message + FUNC_NAME);
                        responseData.message = "Query Failed ";
                        responseData.status = -1;
                        response.status(500).send(responseData);
                    }
                }).catch(function (err) {
                    global.errorLogging(err.message + FUNC_NAME);
                    responseData.message = "Query Failed ";
                    responseData.status = -1;
                    response.status(500).send(responseData);
                });
            } else {
                responseData.status = -1;
                responseData.message = "incomplete request data, Please try again.";
                response.status(500).send(responseData);
                global.errorLogging(err.message + FUNC_NAME);
            }

        } catch (error) {
            responseData.status = -1;
            responseData.message = "something went wrong while getting questions, Please try again.";
            response.status(500).send(responseData);
            global.errorLogging(err.message + FUNC_NAME);
        }
    },
    addStudentsAnswers: (request, response) => {
        const FUNC_NAME = " addStudentsAnswers() ";
        var responseData = {};
        responseData.status = 1;
        try {
            var jwtToken = request.headers.authorization;
            if (request.body.testid && request.body.questionid && jwtToken && request.body.time && request.body.sectionid && request.body.questiontypeid  ) {
                var decode = jwt.verify(jwtToken, global.JWT_SECRET);
                var userid = decode.nUserId;
                var query = `CALL stp_QuizUpdateAnswer(${userid},${request.body.testid},${request.body.sectionid},${request.body.questiontypeid},${request.body.questionid},'${request.body.answer}','${request.body.time}',${request.body.isfinalsubmit});`;
                // console.log(query);
                DBConnection.executequery(query).then(function (resp) {
                    if (resp) {
                        responseData.data = resp;
                        response.status(200).send(responseData);
                    } else {
                        responseData.status = -1;
                        responseData.message = "something went wrong while saving answers, Please try again.";
                        response.status(500).send(responseData);
                        global.errorLogging(responseData.message + FUNC_NAME);
                    }
                }).catch(function (err) {
                    global.errorLogging(err.message + FUNC_NAME);
                    response.status(503).send(null);
                });
            } else {
                responseData.status = -1;
                responseData.message = "Invalid parameters Please try again.";
                response.status(500).send(responseData);
                global.errorLogging(responseData.message + FUNC_NAME);
            }
        } catch (err) {
            responseData.status = -1;
            responseData.message = "something went wrong while saving answers, Please try again.";
            response.status(500).send(responseData);
            global.errorLogging(err.message + FUNC_NAME);
        }
    },


    getResults: (request, response) => {
        const FUNC_NAME = " getResults() ";
        var responseData = {};
        responseData.status = 1;
        try {
            // var jwtToken = request.headers.authorization;
            if (request.body.centerid) {
                // var decode = jwt.verify(jwtToken, global.JWT_SECRET);
                // var userid = decode.nUserId;
                var query = `CALL stp_QuizGetResultByCenter('${request.body.centerid}');`;
                DBConnection.executequery(query).then(function (resp) {
                    if (resp && resp[0] && resp[0][0]) {
                        responseData.data = resp[0];
                        response.status(200).send(responseData);
                    } else {
                        responseData.status = -1;
                        responseData.message = "something went wrong while getting result, Please try again.";
                        response.status(500).send(responseData);
                        global.errorLogging(responseData.message + FUNC_NAME);
                    }
                }).catch(function (err) {
                    global.errorLogging(err.message + FUNC_NAME);
                    response.status(503).send(null);
                });
            } else {
                responseData.status = -1;
                responseData.message = "Invalid parameters Please try again.";
                response.status(500).send(responseData);
                global.errorLogging(responseData.message + FUNC_NAME);
            }
        } catch (err) {
            responseData.status = -1;
            responseData.message = "something went wrong while getting result, Please try again.";
            response.status(500).send(responseData);
            global.errorLogging(err.message + FUNC_NAME);
        }
    },
    getExamList: (request, response) => {
        const FUNC_NAME = " getExamList() ";
        var responseData = {};
        responseData.status = 1;
        try {
            var query = `CALL stp_QuizGetExamList();`;
            DBConnection.executequery(query).then(function (resp) {
                if (resp && resp[0] && resp[0][0]) {
                    responseData.data = resp[0];
                    response.status(200).send(responseData);
                } else {
                    responseData.status = -1;
                    responseData.message = "something went wrong while getting result, Please try again.";
                    response.status(500).send(responseData);
                    global.errorLogging(responseData.message + FUNC_NAME);
                }
            }).catch(function (err) {
                global.errorLogging(err.message + FUNC_NAME);
                response.status(503).send(null);
            });
        } catch (error) {
            responseData.status = -1;
            responseData.message = "something went wrong while getting result, Please try again.";
            response.status(500).send(responseData);
            global.errorLogging(error.message + FUNC_NAME);
        }
    },
    getStoredQuestions: (request, response) => {
        const FUNC_NAME = " getStoredQuestions() ";
        var responseData = {};
        responseData.status = 1;
        try {
            var jwtToken = request.headers.authorization;
            if (jwtToken){
                var decode = jwt.verify(jwtToken, global.JWT_SECRET);
                var userid = decode.nUserId;
                var testid = decode.TestId;
                startExam(testid, userid, '', 1,(functionError, examdetails) => {
                    if (functionError) {
                        responseData.status = -1;
                        responseData.message = 'something went wrong while getting details'
                        response.status(500).send(responseData);
                    } else {
                        responseData.status = 1;
                        responseData.message = examdetails;
                        response.status(200).send(responseData);
                    }
                });
            }
            else {
                responseData.status = -1;
                responseData.message = "something went wrong while getting details";
                response.status(500).send(responseData);
            }
        }catch(err){
            responseData.status = -1;
            responseData.message = "something went wrong while starting exam, Please try again.";
            response.status(500).send(responseData);
            global.errorLogging(err.message + FUNC_NAME);
        }
    }
}
function generateRandomNumbers(nTotalNumbers, nMaxNumber, arrquestions, callback) {
    const FUNC_NAME = " generateRandomNumbers() ";
    var arrFinalQuestions = arrquestions.split(',');
    console.log(arrFinalQuestions);
    try {
        var arr = [];
        var arr1 = [];
        while (arr.length < nTotalNumbers) {
            var r = Math.floor(Math.random() * nMaxNumber);
            if (arr.indexOf(r) === -1) {
                arr1.push(arrFinalQuestions[r]);
                arr.push(r);
            }
        }
        callback(null, arr1);
    } catch (err) {
        callback(err)
        global.errorLogging(err.message + FUNC_NAME);
    }

}
// function startExam(examID, userid, examstarttime, status, callback) {
//     const FUNC_NAME = " startExam() ";
//     var responseData = {};
//     try {
//             var query = `CALL stp_QuizGetQuestionsPerSection('${examID}');`;
//             DBConnection.executequery(query).then(function (resp) {
//                 if (resp && resp[0] && resp[0][0]) {
//                     var arrSectionWiseQuestionIds = resp[0][0].sSectionWiseQuestionIds.split('|');
//                     var arrTotalSectionIds = resp[0][0].sSectionIds.split(',');
//                     var arrTotalSectionNames = resp[0][0].sSectionName.split(',');
//                     var arrTotalSectionQuestions = resp[0][0].sTotalSectionQuestions.split(',');
//                     var nTotalRandomNumber = (resp[0][0].nMCQQuestion / arrTotalSectionIds.length);
//                     var arrSection = [];
//                     var sQuestionsToInsert = "";
//                     for (var i = 0; i < arrTotalSectionIds.length; i++) {
//                         var objSection = {};
//                         generateRandomNumbers(nTotalRandomNumber, arrTotalSectionQuestions[i], arrSectionWiseQuestionIds[i], (err, resp) => {
//                             objSection.sectionId = arrTotalSectionIds[i];
//                             objSection.sectionName = arrTotalSectionNames[i];
//                             objSection.questionIds = '{' + resp + '}';
//                             if (i == 0) {
//                                 sQuestionsToInsert = resp;
//                             } else {
//                                 sQuestionsToInsert = sQuestionsToInsert + ',' + resp;
//                             }
//                             arrSection.push(objSection);
//                         });
//                     }
//                     // console.log(sQuestionsToInsert);
//                     var query = `CALL stp_QuizGetRandomQuestion(1,${userid}, ${examID}, '${sQuestionsToInsert}','${examstarttime}');`;
//                     DBConnection.executequery(query).then(function (resp) {
//                         if (resp) {
//                             console.log(resp);
//                         }
//                     });
//                     responseData.testid = resp[0][0].nTestCreatedId;
//                     responseData.testname = resp[0][0].sTestName;
//                     responseData.centerid = resp[0][0].nCenterId;
//                     responseData.totalexamtime = resp[0][0].dTotalExamTime;
//                     responseData.description = resp[0][0].sDescription;
//                     // responseData.examid = examID;
//                     responseData.sections = arrSection;

//                     callback(null, responseData);
//                 } else {
//                     global.errorLogging(err.message + FUNC_NAME);
//                     callback('Query Failed');
//                 }
//             }).catch(function (err) {
//                 global.errorLogging(err.message + FUNC_NAME);
//                 callback('Query Failed');
//             });
//     } catch (error) {
//         global.errorLogging(err.message + FUNC_NAME);
//         callback('something went wrong while starting exam, Please try again.');
//     }
// }



function startExam(examID, userid, examstarttime, studentstatus, callback) {
    const FUNC_NAME = " startExam() ";
    var responseData = {};
    try {
        if (studentstatus == 1) {
            var query = `CALL stp_QuizGetUserQuestions('${examID}','${userid}');`;
            DBConnection.executequery(query).then(function (resp) {
                if (resp && resp[0] && resp[0][0]) {
                    var arrSectionId = resp[0][0].sSectionIds.split(',');
                    var arrSectionName = resp[0][0].sSectionName.split(',');
                    var arrQuestionIdPerSection = resp[0][0].nQuestionId.split('|');
                    var arrSection = [];
                    for (var i = 0; i < arrSectionId.length; i++) {
                        var objSection = {};
                        objSection.sectionId = arrSectionId[i];
                        objSection.sectionName = arrSectionName[i];
                        objSection.questionIds = '{' + arrQuestionIdPerSection[i] + '}';
                        arrSection.push(objSection);
                    }
                    responseData.testid = resp[0][0].nTestCreatedId;
                    responseData.testname = resp[0][0].sTestName;
                    responseData.centerid = resp[0][0].nCenterId;
                    responseData.totalexamtime = resp[0][0].dTotalExamTime;
                    responseData.description = resp[0][0].sDescription;
                    responseData.totalescapedtime = resp[0][0].tQuestionTime;
                    responseData.sections = arrSection;
                    callback(null, responseData);
                } else {
                    global.errorLogging(err.message + FUNC_NAME);
                    callback('Query Failed');
                }
            }).catch(function (err) {
                global.errorLogging(err.message + FUNC_NAME);
                callback('Query Failed');
            });
        } else {
            var query = `CALL stp_QuizGetQuestionsPerSection('${examID}');`;
            DBConnection.executequery(query).then(function (resp) {
                if (resp && resp[0] && resp[0][0]) {
                    var arrSectionWiseQuestionIds = resp[0][0].sSectionWiseQuestionIds.split('|');
                    var arrTotalSectionIds = resp[0][0].sSectionIds.split(',');
                    var arrTotalSectionNames = resp[0][0].sSectionName.split(',');
                    var arrTotalSectionQuestions = resp[0][0].sTotalSectionQuestions.split(',');
                    var nTotalRandomNumber = (resp[0][0].nMCQQuestion / arrTotalSectionIds.length);
                    var arrSection = [];
                    var sQuestionsToInsert = "";
                    for (var i = 0; i < arrTotalSectionIds.length; i++) {
                        var objSection = {};
                        generateRandomNumbers(nTotalRandomNumber, arrTotalSectionQuestions[i], arrSectionWiseQuestionIds[i], (err, resp) => {
                            objSection.sectionId = arrTotalSectionIds[i];
                            objSection.sectionName = arrTotalSectionNames[i];
                            objSection.questionIds = '{' + resp + '}';
                            if (i == 0) {
                                sQuestionsToInsert = resp;
                            } else {
                                sQuestionsToInsert = sQuestionsToInsert + ',' + resp;
                            }
                            arrSection.push(objSection);
                        });
                    }
                    // console.log(sQuestionsToInsert);
                    var query = `CALL stp_QuizGetRandomQuestion(1,${userid}, ${examID}, '${sQuestionsToInsert}','${examstarttime}');`;
                    DBConnection.executequery(query).then(function (resp) {
                        if (resp) {
                            console.log(resp);
                        }
                    });
                    responseData.testid = resp[0][0].nTestCreatedId;
                    responseData.testname = resp[0][0].sTestName;
                    responseData.centerid = resp[0][0].nCenterId;
                    responseData.totalexamtime = resp[0][0].dTotalExamTime;
                    responseData.description = resp[0][0].sDescription;
                    responseData.sections = arrSection;
                    callback(null, responseData);
                } else {
                    global.errorLogging(err.message + FUNC_NAME);
                    callback('Query Failed');
                }
            }).catch(function (err) {
                global.errorLogging(err.message + FUNC_NAME);
                callback('Query Failed');
            });
        }
    } catch (error) {
        global.errorLogging(err.message + FUNC_NAME);
        callback('something went wrong while starting exam, Please try again.');
    }
}