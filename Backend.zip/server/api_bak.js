const FILE_NAME = ' APIHandler.js ';

const DBConnection = require('./DBOperations/MySQLOperations'); //Database operations 

const global = require('./global.js');

const md5 = require('md5');

const moment = require('moment');

const jwt = require('jsonwebtoken');


module.exports = {

    userLogin: (request, response) => {

        const FUNC_NAME = " userLogin() ";

        var responseData = {};

        responseData.status = 1;

        try {

            if (request.body.loginId && request.body.password) {

                var sPassword = md5(global.SALT + request.body.password);

                var sFirstName = request.body.fname || "";

                var sLastName = request.body.lname || "";

                var sUserName = request.body.loginId || "";

                var sEmailId = request.body.email || "";

                var sContactNumber = request.body.cnumber || "";

                var nRequestType = request.body.requesttype || "";

                var nRoleId = request.body.roleId || 0;

                var sCenterCode = "";

                if (nRequestType == 3) {

                    sCenterCode = request.body.centercode;

                }

                var query = `CALL stp_QuizGetUserDetail( ${nRequestType},'${sFirstName}','${sLastName}','${sUserName}','${sEmailId}','${sContactNumber}','${sPassword}', ${nRoleId},'${sCenterCode}');`;

                console.log(query);

                DBConnection.executequery(query).then(function(resp) {



                    if (resp[0] != undefined) {

                        var userData = resp[0][0];



                        if (userData != undefined && userData.sPassword == sPassword) {

                            var currntdatetime = moment(new Date()).format("YYYYMMDDHHmmssms");

                            var sessionID = sUserName + currntdatetime + global.SALT;

                            sessionID = md5(sessionID);

                            var expiresIn = global.getElapsedTime();

                            var sJWTBody = {};

                            sJWTBody.nCenterId = userData.nCenterId;

                            sJWTBody.sUsername = userData.sUsername;

                            sJWTBody.nUserId = userData.nUserId;

                            sJWTBody.nRoleId = userData.nRoleId

                            var jwtToken = jwt.sign(sJWTBody, global.JWT_SECRET, { expiresIn: expiresIn });

                            responseData.jwtToken = jwtToken;

                            global.jwtTokens.push(jwtToken);

                            responseData.sessionId = sessionID;

                            global.session[sessionID] = userData.nUserName;

                            responseData.LoginStatus = userData.bStatus[0];

                            responseData.IsActive = userData.bIsActive[0];

                            responseData.CreatedOn = userData.dCreatedOn;

                            responseData.LoginTime = userData.dLoginTime;

                            responseData.TotalTimeEscape = userData.dTotalTimeEscape;

                            responseData.CenterId = userData.nCenterId;

                            responseData.CreatedBy = userData.nCreatedBy;

                            responseData.lastQuestionId = userData.nlastQuestionId;

                            responseData.RoleId = userData.nRoleId;

                            responseData.UserId = userData.nUserId;

                            responseData.EmailId = userData.sEmailId;

                            responseData.FirstName = userData.sFirstName;

                            responseData.LastName = userData.sLastName;

                            responseData.MobileNumber = userData.sMobileNumber;

                            responseData.SystemInfo = userData.sSystemInfo;

                            responseData.Username = userData.sUsername;

                        } else {
                            responseData.status = -1;
                            responseData[global.message] = "Invalid username or password";
                            response.status(200).send(responseData);
                        }

                    } else {

                        responseData.status = -1;
                        responseData[global.message] = "Invalid username or password";
                        response.status(200).send(responseData);
                    }

                    responseData.message = "Login Successfull";

                    response.status(200).send(responseData);

                });

            }

        } catch (err) {

            responseData.status = -1;

            responseData.message = "something went wrong while login, Please try again.";

            response.status(500).send(responseData);

            global.errorLogging(err.message + FUNC_NAME);

        }

    },

    userLogout: (request, response) => {

        const FUNC_NAME = " userLogout() ";

        var responseData = {};

        responseData.status = 1;

        try {

            var sessionId = request.body.sessionId;

            if (sessionId != undefined) {

                delete global.session[sessionId];

            }

            var jwtToken = request.headers.authorization;

            var nIndex = global.jwtTokens.indexOf(jwtToken);

            if (nIndex >= 0) {

                global.jwtTokens.splice(nIndex, 1);

            }

            responseData[global.message] = "Successfully logged out."

            response.status(200).send(responseData);



        } catch (err) {

            responseData.status = -1;

            responseData[global.message] = "something went wrong while logout, Please try again.";

            response.status(500).send(responseData);

            global.errorLogging(err.message + FUNC_NAME);

        }



    },

    fileupload: function(request, response) {

        const FUNC_NAME = " uploadFile() ";

        var responseData = {};

        responseData.status = 1;

        responseData[global.message] = "File uploaded successfully.";

        try {

            var directory = "";

            var orignalFileName = "";

            var systemFileName = "";

            var userName = "";

            var storage = multer.diskStorage({

                destination: function(req, file, callback) {

                    directory = global.config.server.fileuploadpath;

                    if (!fs.existsSync(directory)) {

                        fs.mkdirSync(directory);

                    }

                    directory = path.join(directory, moment(new Date()).format("YYYYMMDD"));

                    if (!fs.existsSync(directory)) {

                        fs.mkdirSync(directory);

                    }

                    callback(null, directory);

                },

                filename: function(req, file, callback) {

                    userName = req.loginInfo[global.userName];

                    orignalFileName = file.originalname;

                    fileString = req.body.fileString;

                    var fileNameparts = orignalFileName.split(".");

                    if (fileNameparts[fileNameparts.length - 1] != 'json') {

                        responseData.status = -1;

                        responseData[global.message] = "File not supported.";

                        response.status(400).send(responseData);

                        return;

                    }

                    systemFileName = fileNameparts[0] + "_" + moment(new Date()).format("YYYYMMDDHHmmssms") + "." + fileNameparts[1];

                    callback(null, systemFileName);

                }

            });

            // finally Uploading File

            var upload = multer({ storage: storage }).single('file');

            upload(request, response, function(err) {

                if (err) {

                    responseData.status = -1;

                    responseData[global.message] = "Failed to upload the file. Please try again.";

                    return response.status(500).send(responseData);

                }

                var filePath = path.join(directory, systemFileName);

                async.waterfall([

                    function tuncateTempTable(callback) {

                        var query = "";

                        query = "truncate tbl_TempQuizUploadMaster;"

                        DBConnection.executequery(query).then(function(resp) {

                            callback(null);

                        }).catch(function(err) {

                            global.errorLogging(err.message + FUNC_NAME);

                            callback("Failed to tuncate temp table.");

                            return;

                        });

                    },

                    function loadData(callback) {

                        var query = "";



                        query = "LOAD DATA LOCAL INFILE '" + filePath + "' INTO TABLE tbl_TempQuizUploadMaster (sData) set nLineNumber = null ;";

                        DBConnection.executequery(query).then(function(resp) {

                            callback(null);

                        }).catch(function(err) {

                            global.errorLogging(err.message + FUNC_NAME);

                            callback("Failed to load data.");

                            return;

                        });

                    },

                    function processData(callback) {

                        var query = "CALL stp_QuizUploadMaster(" + userName + "', );";

                        DBConnection.executequery(query).then(function(resp) {

                            if (resp[0] != undefined && resp[0][0] != undefined && resp[0][0].Error_String != undefined) {

                                global.errorLogging(resp[0][0].Error_String + FUNC_NAME);

                                callback("Failed to process data.");

                                return;

                            } else {

                                callback(null);

                            }

                        }).catch(function(err) {

                            global.errorLogging(err.message + FUNC_NAME);

                            callback("Failed to process data.");

                            return;

                        });

                    }
                ], function finalCallbeck(err, result) {

                    if (err == null) {

                        responseData.status = 1;

                        response.send(responseData);

                    } else {

                        responseData.status = -1;

                        responseData[global.message] = err;

                        if (responseData.errors.length > 0) {

                            response.status(200).send(responseData);

                        } else {

                            response.status(503).send(responseData);

                        }



                    }

                });

            });

        } catch (err) {

            global.errorLogging(err.message + FUNC_NAME);

            responseData.statuscode = -1;

            responseData.errorstring = "Something went wrong while uploading the file. Please try again.";

            response.status(500).send(responseData);

        }

    },


    addUpdateCenter: (request, response) => {

        const FUNC_NAME = " addUpdateCenter() ";

        var responseData = {};

        responseData.status = 1;

        try {

            var nCenterId = request.body.CenterId;

            var sCenterCode = request.body.CenterCode;

            var sCenterName = request.body.CenterName;

            var sCenterAddress = request.body.CenterAddress;

            var sContactPerson = request.body.ContactPerson;

            var sContactNumber = request.body.ContactNumber;

            var bIsActive = request.body.IsActive;

            var sCreatedBy = request.body.CreatedBy;



            var query = `CALL stp_QuizAddUpdateCenter( ${nCenterId},'${sCenterCode}','${sCenterName}','${sCenterAddress}','${sContactPerson}','${sContactNumber}',${bIsActive},'${sCreatedBy}');`;

            console.log(query);



            DBConnection.executequery(query).then(function(resp) {

                responseData.data = resp;

                response.status(200).send(responseData);

            }).catch(function(err) {

                global.errorLogging(err.message + FUNC_NAME);

                response.status(503).send(null);

            });



        } catch (err) {

            responseData.status = -1;

            responseData.message = "something went wrong while logout, Please try again.";

            response.status(500).send(responseData);

            global.errorLogging(err.message + FUNC_NAME);

        }

    },

    getCenterList: (request, response) => {

        const FUNC_NAME = " getCenterList() ";

        var responseData = {};

        responseData.status = 1;

        try {

            var query = `CALL stp_QuizGetCenterList();`;

            console.log(query);



            DBConnection.executequery(query).then(function(resp) {

                responseData.data = resp;

                response.status(200).send(responseData);

            }).catch(function(err) {

                global.errorLogging(err.message + FUNC_NAME);

                response.status(503).send(null);

            });

        } catch (err) {

            responseData.status = -1;

            responseData.message = "something went wrong while logout, Please try again.";

            response.status(500).send(responseData);

            global.errorLogging(err.message + FUNC_NAME);

        }

    },
    addUpdateSection: (request, response) => {

        const FUNC_NAME = " addUpdateSection() ";

        var responseData = {};

        responseData.status = 1;

        try {



            var nSectionId = request.body.SectionId;

            var sSectionCode = request.body.SectionCode;

            var sSectionName = request.body.SectionName;

            var sDescription = request.body.Description;

            var bIsActive = request.body.IsActive;

            var sCreatedBy = request.body.CreatedBy;



            var query = `CALL stp_QuizAddUpdateSection( ${nSectionId},'${sSectionCode}','${sSectionName}','${sDescription}',${bIsActive},'${sCreatedBy}');`;

            console.log(query);



            DBConnection.executequery(query).then(function(resp) {

                responseData.data = resp;

                response.status(200).send(responseData);

            }).catch(function(err) {

                global.errorLogging(err.message + FUNC_NAME);

                response.status(503).send(null);

            });



        } catch (err) {

            responseData.status = -1;

            responseData.message = "something went wrong while logout, Please try again.";

            response.status(500).send(responseData);

            global.errorLogging(err.message + FUNC_NAME);

        }

    },

    addUpdateExam: (request, response) => {

        const FUNC_NAME = " AddUpdateExam() ";

        var responseData = {};

        responseData.status = 1;

        try {



            var nTestCreatedId = request.body.TestCreatedId;

            var sTestId = request.body.TestId;

            var nCenterId = request.body.CenterId;

            var nSectionId = request.body.SectionId;

            var nMCQQuestion = request.body.MCQQuestion;

            var nProgrammingQuestion = request.body.ProgrammingQuestion;

            var nTotalQuestions = request.body.TotalQuestions;

            var dTotalExamTime = request.body.TotalExamTime;

            var bIsActive = request.body.IsActive;

            var sDescription = request.body.Description;

            var sCreatedBy = request.body.CreatedBy;



            var query = `CALL stp_QuizAddUpdateExam( ${nTestCreatedId},'${sTestId}',${nCenterId},${nSectionId},${nMCQQuestion},${nProgrammingQuestion},${nTotalQuestions},${dTotalExamTime},${bIsActive},'${sDescription}','${sCreatedBy}');`;

            console.log(query);



            DBConnection.executequery(query).then(function(resp) {

                responseData.data = resp;

                response.status(200).send(responseData);

            }).catch(function(err) {

                global.errorLogging(err.message + FUNC_NAME);

                response.status(503).send(null);

            });



        } catch (err) {

            responseData.status = -1;

            responseData.message = "something went wrong while logout, Please try again.";

            response.status(500).send(responseData);

            global.errorLogging(err.message + FUNC_NAME);

        }

    }

}