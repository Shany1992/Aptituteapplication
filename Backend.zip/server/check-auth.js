const jwt = require('jsonwebtoken');
var global = require('./global.js');
const fs = require('fs');
const moment = require('moment');

module.exports = function (req, res, next) {
    const FUNC_NAME = " authenticate()"
    var token;
    var responseData = {};
    responseData.status = -1;
    var logData = {};
    logData.errMessage = "Unauthorized Access.";
    logData.remoteAdd = req._remoteAddress;
    logData.jwtToken = token;
    logData.timestamp = moment(new Date()).format("YYYY-DD-MM HH:mm:ss:ms");
    try {
        token = req.headers.authorization;
        if (token == undefined) {
            fs.appendFile(global.jwtAuthCheckLog, JSON.stringify(logData) + "\n", function (err) {
                if (err) global.errorLogging(err.message + FUNC_NAME);;
            });
            responseData[global.message] = "Authentication Failed.";
            return res.status(401).json(responseData);
        }
        var decode = jwt.verify(token, global.JWT_SECRET);
        var nIndex = global.jwtTokens.indexOf(token);
        if (nIndex < 0) {
            responseData[global.message] = "Authentication Failed.";
            fs.appendFile(global.jwtAuthCheckLog, JSON.stringify(logData) + "\n", function (err) {
                if (err) global.errorLogging(err.message + FUNC_NAME);;
            });
            return res.status(401).json(responseData);
        }
        req.loginInfo = decode;
        next();
    } catch (error) {
        var nIndex = global.jwtTokens.indexOf(token);
        if (nIndex > 0) {
            global.jwtTokens.splice(nIndex, 1);
        }
        responseData[global.message] = "Authentication Failed.";
        fs.appendFile(global.jwtAuthCheckLog, JSON.stringify(logData) + "\n", function (err) {
            if (err) global.errorLogging(err.message + FUNC_NAME);;
        });
        return res.status(401).json(responseData);
    }
};
