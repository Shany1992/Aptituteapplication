const FILE_NAME = ' MySQLOperations.js ';
const mysql = require('mysql');
const Q = require('q');
const global = require('../global.js');

var pool = mysql.createPool({
    connectionLimit: global.config.db.connectionLimit,
    host: global.config.db.dbserver,
    user: global.config.db.dbuser,
    password: global.config.db.dbPassword,
    database: global.config.db.databasename,
    port: global.config.db.dbport
});

var heartBeatMysql = function () {
    var FUNC_NAME = " heartBeatMysql()";
    try {
        var query = "select 1;";
        pool.query(query, function (err, rows, fields) {
            if (err) {
                console.log(err.message + FUNC_NAME);
            }
        });
    } catch (err) {
        console.log(err.message + FUNC_NAME);
    }
}
setInterval(heartBeatMysql, 15 * 60 * 1000);

module.exports = {
    executequery: function (query) {
        const FUNC_NAME = " executequery() ";
        try {
            var deferred = Q.defer();
            var result = {};
            pool.query(query, function (err, rows, fields) {
                if (err) {
                    console.log(err.message + FUNC_NAME);
                    deferred.reject(err);
                }
                else {
                    deferred.resolve(rows);
                }
            });
            return deferred.promise;
        } catch (err) {
            console.log(err.message + FUNC_NAME);
            deferred.reject(err);
        }
    },
};