const fs = require('fs');
const moment = require('moment');
const appconfig = require('./appconfig');
exports.config = appconfig.readconfig();
exports.SALT = "63moons@123";
exports.JWT_SECRET = "63moons@123";
exports.jwtTokens = [];
exports.session = {};
exports.message = "message";
var LoggingDir = exports.config.server.LoggingDir;
if (LoggingDir == undefined)
    LoggingDir = "./logs/";
if (!fs.existsSync(LoggingDir)) {
    fs.mkdirSync(LoggingDir);
}
exports.currntdate = moment(new Date()).format("YYYYMMDD");
var logDir = LoggingDir + "/" + exports.currntdate;
if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir);
}
exports.fatalErrorLog = logDir + "/" + exports.currntdate + "_fatalError.log";
exports.jwtAuthCheckLog = logDir + "/" + exports.currntdate + "jwtAuthCheck.log";
exports.errorLogging = function(errorMessage) {
    const FUNC_NAME = " errorLogging()";
    try {
        var logMessage = moment(new Date()).format("YYYY-MM-DD HH:mm:ss:ms") + ":" + errorMessage;
        fs.appendFile(exports.fatalErrorLog, logMessage + "\n", function(err) {
            if (err) console.log(err.message + FUNC_NAME);
        });
    } catch (err) {
        exports.errorLogging(err.message + FUNC_NAME);
    }
}


exports.getElapsedTime = function() {
    var sessionTime = exports.config.server.sessionlogouttime.toString().split(':');
    return moment().hour(sessionTime[0]).minute(sessionTime[1]).second(0).diff(moment(), 'seconds');
}