//CR5206
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const global = require('./server/global');
var port = global.config.server.port || 8081;
var app = express();
app.set('json spaces', 2);
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin,X-Requested-With, Content-Type, Accept, authorization");
    res.header("Access-Control-Allow-Methods", "*");
    next();
});
app.use(express.static(path.join(process.cwd(), 'logs')));
app.use(express.static(path.join(process.cwd(), 'recordings')));
var APIHandler = require('./server/APIHandler');
var authenticate = require('./server/check-auth');
app.post('/api/login', APIHandler.userLogin);
app.post('/api/logout', authenticate, APIHandler.userLogout);
app.post('/api/fileupload', authenticate, APIHandler.fileupload);
app.post('/api/addupdatecenter', authenticate, APIHandler.addUpdateCenter);
app.get('/api/getcenterlist', authenticate, APIHandler.getCenterList);
app.post('/api/addupdatesection', authenticate, APIHandler.addUpdateSection);
app.get('/api/getsectionlist',authenticate, APIHandler.getSectionList);
app.post('/api/addupdateexam', authenticate, APIHandler.addUpdateExam);
app.post('/api/startexam'/*, authenticate*/, APIHandler.startExam); // Redundent
app.post('/api/addupdateuser', authenticate, APIHandler.addUpdateUser);
app.post('/api/fileread', authenticate, APIHandler.fileread);
app.post('/api/test',APIHandler.test);
app.post('/api/getsectionwisequestions', authenticate, APIHandler.getSectionWiseQuestions);
app.post('/api/getaddstudentanswers', authenticate, APIHandler.addStudentsAnswers);
app.post('/api/getresults', authenticate, APIHandler.getResults);
app.get('/api/getexamlist', authenticate, APIHandler.getExamList);
app.post('/api/getstoredquestions', authenticate, APIHandler.getStoredQuestions);
app.listen(port, '0.0.0.0');
console.log("server started on:" + port);