CREATE DEFINER=`root`@`localhost` PROCEDURE `stp_QuizUploadUser`(
	in V_nUserId int,-- nCreatedBy value-Whose gone upload the file
    in V_nCenterId int
)
BEGIN
declare V_n_UserId int;

truncate table tbl_temp_qusermaster;

insert into tbl_temp_qusermaster
(	
	nLineNo,
	sFirstName , 
	sLastName ,
	sUsername
)
select
	nLineNo,
	 -- ltrim(rtrim(replace(substring(substring_index(sData,',',1),  length(substring_index(sData,',',1-1))+1),',',''))) as firstName,
     replace(substring(substring_index(sData,',',1),  length(substring_index(sData,',',0))+1),',','') as firstName,
     -- ltrim(rtrim(replace(substring(substring_index(sData,',',2),  length(substring_index(sData,',',2-1))+1),',',''))) as lastName,
      replace(substring(substring_index(sData,',',2),  length(substring_index(sData,',',1))+1),',','') as lastName,
     -- ltrim(rtrim(replace(substring(substring_index(sData,',',3),  length(substring_index(sData,',',3-1))+1),',',''))) as username
     replace(substring(substring_index(sData,',',3),  length(substring_index(sData,',',2))+1),',','') as username
from tbl_quploadmaster;


truncate table tbl_quploadmasterlog;
insert into tbl_quploadmasterlog
(
	nLineNo,
    sReason
)
select 
	nLineNo,
    'FirstName is Blank'
from tbl_temp_qusermaster
where sFirstName='' or sFirstName=null
union
select 
	nLineNo,
    'Length of FirstName is Greater than 100'
from tbl_temp_qusermaster
where length(sFirstName)>100
union
select 
	nLineNo,
    'Length of LastName is Greater than 100'
from  tbl_temp_qusermaster
where length(sLastName)>100
union
select 
	nLineNo,
    'username is Blank'
from tbl_temp_qusermaster
where sUsername='' or sUsername=null
union
select 
	nLineNo,
    'Length of Username is Greater than 50'
from tbl_temp_qusermaster
where length(sUsername)>50;


delete from tbl_temp_qusermaster where sFirstName='' or sFirstName=null;
delete from tbl_temp_qusermaster where length(sFirstName)>100;
delete from tbl_temp_qusermaster where length(sLastName)>100;
delete from tbl_temp_qusermaster where sUsername='' or sUsername=null;
delete from tbl_temp_qusermaster where length(sUsername)>50;


insert into tbl_qusermaster
(
	nRoleId,
	sFirstName,
	sLastName,
	sUsername,
	nCreatedBy,
	dCreatedOn,
	nCenterId,
	sPassword
)
select 
	2,
	sFirstName,
	sLastName,
	sUsername,
	V_nUserId,
	now(),
	V_nCenterId,
	'6c38da53eaef30a6f6bea59e4b407112'
from tbl_temp_qusermaster;
     
set V_n_UserId=(select last_insert_id());-- users Id which created in usermaster table

truncate table tbl_qusercentermapping;
insert into tbl_qusercentermapping
(
	nUserId,
	nCenterId
)
select 
	nUserId,
	nCenterId
from tbl_qusermaster;
END