import { Component, OnInit, ViewChild } from '@angular/core';
import { CenterService } from '../center/center.service';
import { SectionService } from '../section/section.service';
import { MatSelect, MatTableDataSource } from '@angular/material';
import { ExamService } from './exam.service';
declare var $: any;

@Component({
  selector: 'app-exam',
  templateUrl: './exam.component.html',
  styleUrls: ['./exam.component.css']
})

export class ExamComponent implements OnInit {
  @ViewChild('select', { static: true }) select: MatSelect;
  exam: any = {
    'cname': null,
    'tquestion': null,
    'cmcq': null,
    'cprogramming': null,
    'cdescription':null
  };
  centerData: any;
  sectionList: any;
  questionnumber: any;
  finalquestions: string;
  questiondata: any = [];
  examData: any;

  constructor(private service: CenterService, private eservice: SectionService, private exservice: ExamService) { }

  ngOnInit() {
    this.getCenterlist();
    this.getSectionList();
    this.getExamList();
  }

  getCenterlist(): any {
    try {
      this.service.getdata().then(data => {
        if (data["status"] == 1) {
          this.centerData = data["data"];
        } else {

        }

      },err=>{

      })
    } catch (error) {

    }
  }

  getSectionList(): any {
    try {
      this.eservice.getSectionList().then(data => {
        if (data["status"] == 1) {
          this.sectionList = data["data"];
         // console.log(this.sectionList);
        } else {

        }

      },err=>{

      })
    } catch (error) {

    }
  }

  addquestion(id: any, event: any, index: any) {
    //// console.log(event.target.selected);
    // this.select.close();
    var questionspersection = "";
    try {
      if (id && this.select.selected[index].selected) {

        $("#addquestion").modal('show');
      }

    } catch (error) {

    }
  }

  reset() {
    $("#addquestion").modal('hide');
  }

  savequestion() {

    if (this.questionnumber) {
      this.questiondata.push(this.questionnumber);
      this.questionnumber = "";
      $("#addquestion").modal('hide');

      this.finalquestions = this.questiondata.join(',');
      //// console.log(this.finalquestions);
    } else {
      this.questionnumber = "";
      $("#addquestion").modal('hide');
      this.exam.tquestion  = null;
    }
  }

  save() {

    var requestobject = {
      "TestCreatedId": 0,
      "TestName": this.exam.ename,
      "CenterId": this.exam.cname,
      "SectionId": this.exam.sectionId.join(','),
      "MCQQuestion": null,
      "ProgrammingQuestion": null,
      "TotalQuestions": null,
      "TotalExamTime": this.exam.ttime,
      "Description": this.exam.cdescription,
      "questionspersection": this.finalquestions
    }
    try {
      this.exservice.save(requestobject).then(data=>{
        if(data && data["status"] == 1){
          this.getExamList();
          $('#addexam').modal('hide');
        }else{

        }
      },err=>{

      })
    } catch (error) {

    }
  }

  getExamList(){
    try { 
      this.exservice.getList().then(data=>{
        if(data && data["status"]==1){
          this.examData = new MatTableDataSource(data["data"]);
        }else{

        }
    
      },err=>{

      })

    } catch (error) {
      
    }
  }

}
