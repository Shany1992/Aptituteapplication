import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { AppComponent } from '../app.component';

@Injectable({
  providedIn: 'root'
})
export class ExamService {
  token: string;
  headers: any;
  save(requestobj:any) {
  return this.http.post(this.app.url + 'addupdateexam',requestobj,{
    headers:this.headers
  }).toPromise();
  }

  getList(){
    return this.http.get(this.app.url + 'getexamlist',{
      headers:this.headers
    }).toPromise();
  }

  constructor(private app:AppComponent,private http:HttpClient) {
    this.token = sessionStorage.getItem('jwttoken');
    this.headers = new HttpHeaders()
        .set('Authorization', this.token);
   }
}
