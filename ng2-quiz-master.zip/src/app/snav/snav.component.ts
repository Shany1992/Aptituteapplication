import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-snav',
  templateUrl: './snav.component.html',
  styleUrls: ['./snav.component.css'],
  providers:[AuthService]
})
export class SnavComponent implements OnInit {
  type: string;

  constructor(public auth:AuthService) { }

  ngOnInit() {
    this.type = sessionStorage.getItem('type');
  }
}
