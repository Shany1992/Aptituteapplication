import { Component } from '@angular/core';
import { HostListener } from '@angular/core';
import { QuizComponent } from './quiz/quiz.component';
import { Subscription } from 'rxjs';
import { Router, NavigationStart } from '@angular/router';
export let browserRefresh = false;

declare var $: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  url: any = null;
  iscdac: any = 0;
  subscription: Subscription;
  fileDownloadOptions: { fieldSeparator: string; quoteStrings: string; showLabels: boolean; showTitle: boolean; useBom: boolean; noDownload: boolean; headers: any[]; };
  addMessage: string;
  alert : any ={
    'color': null,
    'message':null,
    'status':0
  }
  errorMessage: string;
  nodataMessage:string;
  constructor(private router: Router) {
    // window.addEventListener("backbutton", function (e) {
    //   var confirmationMessage = "Hello how are you?";
    //   console.log("Hello" + e);
    //  // e.returnValue = confirmationMessage;     // Gecko, Trident, Chrome 34+
    //   return confirmationMessage;              // Gecko, WebKit, Chrome <34
    // });
   
    this.fileDownloadOptions = {
      fieldSeparator: ',',
      quoteStrings: '',
      showLabels: false,
      showTitle: false,
      useBom: false,
      noDownload: false,
      headers: []
    };

    this.subscription = router.events.subscribe((event) => {

      if (event instanceof NavigationStart) {

        browserRefresh = !router.navigated;
      }
    });
    // this.url = "http://172.16.50.108:8080/api/";
    this.url = "http://localhost:8080/api/";
    this.iscdac = 1;
    this.addMessage = "Data updated successfully.";
    this.errorMessage = "Something went wrong please contact administrator.";
    this.nodataMessage ="No data found."
  }

  ngOnInit(): void {

  
  }


}
