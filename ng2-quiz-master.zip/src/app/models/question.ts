import { Option } from './option';

export class Question {

    id: number;
    name: string;
    questionTypeId: number;
    options: Option[];
    answered: boolean;
    questionType :{};
    studentselectedanswer:any;
    constructor(data: any) {
        data = data || {};
        this.id = data.id ==undefined ? data.questionid : data.id   ;
        this.name = data.name  ==undefined ? data.question  :data.name;
        this.questionTypeId = data.questionTypeId ==undefined ? data.questiontypeid  :data.questionTypeId;
        this.options = [];
        this.questionType = data.questionType  ==undefined ? data.questiontypename  :data.questionType;
        this.studentselectedanswer = undefined ? "" : data.studentselectedanswer;
        var options = JSON.parse(data.options); 
        if(options){
            options.forEach(o => {
                if(o.id == this.studentselectedanswer){
                    o.isAnswer = true;
                }else{
                    o.isAnswer = false;
                }
                this.options.push(new Option(o));
            });
        }
      
    }
}
