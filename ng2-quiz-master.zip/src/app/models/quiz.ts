import { QuizConfig } from './quiz-config';
import { Question } from './question';

export class Quiz {

    id: number;
    name: string;
    description: string;
    config: QuizConfig;
    questions: Question[];
    questionType: {};
    constructor(data: any) {
        if (data) {
            var count = 0;
            this.id = data.id == undefined ? count+1 :data.id  ;
            this.name = data.name == undefined ? null :data.name  ;
            this.description = data.description == undefined ? null :data.description ; 
            this.config = data.config == undefined ? null: new QuizConfig(data.config);
            this.questions = [];
            // this.questionType =  data.questionType;
            // if(data.questions){
            //     data.questions.forEach(q => {
            //         this.questions.push(new Question(q));
            //     });
            // }

             if(data){
                data.forEach(q => {
                    this.questions.push(new Question(q));
                });
            }
         
        }
    }
}
