import { Component, OnInit } from '@angular/core';
import { SectionService } from './section.service';
declare var $:any;
import * as _moment from 'moment';
import { AppComponent } from '../app.component';
// import { Angular5Csv } from 'angular5-csv/Angular5-csv';
@Component({
  selector: 'app-section',
  templateUrl: './section.component.html',
  styleUrls: ['./section.component.css']
})
export class SectionComponent implements OnInit {
  sectionData: any;
  section:any = {
    "sname":null,
    "description":null
  }
  eform:any = {
    "esname":null,
    "edescription":null
  }
  constructor(private service:SectionService,private app:AppComponent) { }

  ngOnInit() {
    this.getSectionList();
  }

  getSectionList():any{
   try {
    this.service.getSectionList().then(data=>{
      if(data["status"] == 1){
        this.sectionData = data["data"];
        console.log(data);
      }else{
        
      }
       
    })
   } catch (error) {
     
   }
   
  }


  save(type:any):any {
    try {
      var data  :any ={};
      if (type == 1) {
        data = {
          "SectionId":0,
          "SectionName": this.section.sname,
          "Description":this.section.description
        }
          this.service.updateData(data).then(data=>{
            if(data["status"]==1){
              this.closeaddModal();
              this.getSectionList();
            }else{
              this.closeaddModal();
              this.getSectionList();
            }
          })         
    
         
      } else  if (type == 2)  {
        data = {
          "SectionId":   this.eform.sectionid ,
          "SectionName":   this.eform.esname ,
          "Description": this.eform.edescription 
       }

        this.service.updateData(data).then(data=>{
          if(data["status"]==1){
            this.closeeditModal();
            this.getSectionList();
          }else{
            this.closeeditModal();
            this.getSectionList();
          }
         
          // this.getSectionList();
        })
   
      }

    } catch (error) {
      
    }
  }

  getData(infor:any){
    try {
      if(infor){
      
        $('#editsection').modal('show');
        this.eform.esname = infor.sSectionName,
        this.eform.edescription = infor.sDescription
        this.eform.sectionid = infor.nSectionId
      }else{

      }
    } catch (error) {
      
    }
  }


  closeaddModal(){
    $('#addsection').modal('hide');
  }

  closeeditModal(){
    $('#editsection').modal('hide');
  }

  // exportData(){
  //   var fileName = "";
  //   var headers = [];
  //   fileName = "DayWiseException_" + _moment(new Date()).format("YYYYMMDDHHmmss");
  //   var options = JSON.parse(JSON.stringify(this.app.fileDownloadOptions));
  //   options.headers = headers;
  //   try {
  //     this.service.getSectionList().then(data=>{
  //       if(data["status"] == 1){
  //        var exreporttable = data["data"];
  //         new Angular5Csv(exreporttable, fileName, options);
  //       }else{
          
  //       }
         
  //     })
  //    } catch (error) {
       
  //    }
     
   
  // }
}
