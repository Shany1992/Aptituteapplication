import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppComponent } from '../app.component';

@Injectable({
  providedIn: 'root'
})
export class SectionService {
  token: string;
  headers: HttpHeaders;
  constructor(private http:HttpClient,private app:AppComponent) { 
    this.token = sessionStorage.getItem('jwttoken');
    this.headers = new HttpHeaders()
        .set('Authorization', this.token);
  }
  getSectionList():any{
    return this.http.get(this.app.url + 'getsectionlist',{
      headers:this.headers
    }).toPromise();
  }


  updateData(sectionData:any):any{
    return this.http.post(this.app.url + 'addUpdateSection',sectionData,{
      headers:this.headers
    }).toPromise();
  }
}
