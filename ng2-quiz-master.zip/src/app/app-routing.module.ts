import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { QuizComponent } from './quiz/quiz.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './auth.guard';
import { AdashboardComponent } from './adashboard/adashboard.component';
import { UploadComponent } from './upload/upload.component';
import { InformationComponent } from './information/information.component';
import { ThankyouComponent } from './thankyou/thankyou.component';
import { CenterComponent } from './center/center.component';
import { ExamComponent } from './exam/exam.component';
import { TestComponent } from './test/test.component';
import { SectionComponent } from './section/section.component';
const routes: Routes = [
  // {
  //     path: '',
  //     redirectTo: '/app/(login)', 
  //     pathMatch: 'full',
  //   }, {

	// 	path: "app",
	// 	children: [
	// 		{
	// 			path: "login",
	// 			component: LoginComponent
	// 		},
	// 		{
	// 			path: "information",
	// 			outlet: "secondary",
	// 			component: InformationComponent,
	// 			// canActivate: [ AuthGuard ]
	// 		}
	// 	]
	// }
  
  {
    path: '',
    redirectTo: 'login', 
    pathMatch: 'full',
  },
  {
    path:'quiz',
    component:QuizComponent,   // This belongs to exam page and reffer quizcomponent
    canActivate: [AuthGuard]
  },{
    path:'login',
    component:LoginComponent // This belongs to login page and reffer logincomponent
  },{
    path:'dashboard',
    component:AdashboardComponent,   // This belongs to dashboard and reffer quizcomponent
    canActivate: [AuthGuard]
  }
  ,{
    path:'upload',
  
    component:UploadComponent,   // This belongs to upload questions and user list reffer  UploadComponent
    canActivate: [AuthGuard]
  },{
    path:'information',

    component:InformationComponent,   // This belongs to upload questions and user list reffer  UploadComponent
    canActivate: [AuthGuard]
  },{
    path:'thankyou',
    component:ThankyouComponent
  }
  ,{
    path:'center',
    component:CenterComponent, 
     // This belongs to upload questions and user list reffer  UploadComponent
    canActivate: [AuthGuard]
  }
  ,{
    path:'exam',
    component:ExamComponent,  // This belongs to upload questions and user list reffer  UploadComponent
    canActivate: [AuthGuard]            
  },{
    path:'test',
    component:TestComponent
  },{
    path:'section',
    component:SectionComponent,
    // ,   // This belongs to upload questions and user list reffer  UploadComponent
    canActivate: [AuthGuard]  
  }

  
]
@NgModule({
  imports: [
    CommonModule,RouterModule.forRoot(routes, { enableTracing: true
    })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
