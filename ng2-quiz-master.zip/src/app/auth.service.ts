import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
declare var $: any;
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppComponent } from './app.component';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  headers: HttpHeaders;
  token: string;

  constructor(private myRoute: Router,private http:HttpClient,private app:AppComponent) { }
  setToken(data: any) {
    // console.log(data);
    sessionStorage.setItem('username', data["Username"]);
    sessionStorage.setItem('jwttoken', data["jwtToken"]);
    sessionStorage.setItem('sessionid', data["sessionId"]);
    sessionStorage.setItem('roleid', data["RoleId"]);
    sessionStorage.setItem('firstname', data["FirstName"]);
    sessionStorage.setItem('lastname', data["LastName"]);
    sessionStorage.setItem('mobilenumber', data["MobileNumber"]);
    sessionStorage.setItem('emailid', data["EmailId"]);
    sessionStorage.setItem('userid', data["UserId"]);
    sessionStorage.setItem("centerid", data["CenterId"]);

  }
  getToken() {
    return sessionStorage.getItem("jwttoken");
  }
  isLoggedIn() {
    return this.getToken() !== null;
  }
  logout() {
    var session = sessionStorage.getItem("sessionId");
    this.token = sessionStorage.getItem('jwttoken');
    this.headers = new HttpHeaders()
        .set('Authorization', this.token);
    this.http.post(this.app.url + 'logout',{sessionId:session},{
      headers:this.headers 
    }).toPromise().then(data=>{
      if(data && data["status"]==1){
        this.myRoute.navigate(["thankyou"]);
        $('#logout').modal('hide');
        sessionStorage.clear();

      }else{
        $('#logout').modal('hide');
        sessionStorage.clear();
      }
    },err=>{
      console.log(err);
      $('#logout').modal('hide');
      sessionStorage.clear();
    })
  
    // setInterval(() => {

    // }, 5000);
  }

  private isPageRefresh(): boolean {

    // If the router has yet to establish a single navigation, it means that this
    // navigation is the first attempt to reconcile the application state with the
    // URL state. Meaning, this is a page refresh.
    return (!this.myRoute.navigated);

  }
}
