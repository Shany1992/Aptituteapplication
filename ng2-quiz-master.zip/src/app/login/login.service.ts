import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppComponent } from '../app.component';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  headers: HttpHeaders;
  token: string;
  
  constructor(private http:HttpClient,private app:AppComponent) { 
    
    // this.headers = 
  }

  getstoredquestions(tokendata) {
    
    return  this.http.post(this.app.url + 'getstoredquestions','',{
      headers:new HttpHeaders()
      .set('Authorization', tokendata.tokendata)
    }).toPromise();
  }


  login(userdata:any){
    return  this.http.post(this.app.url + 'login',userdata).toPromise();
  }
}
