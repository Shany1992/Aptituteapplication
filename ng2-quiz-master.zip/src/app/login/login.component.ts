import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { AppComponent } from '../app.component';
import { HttpClient } from '@angular/common/http';
import { LoginService } from './login.service';
declare var $;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [LoginService]
})
export class LoginComponent implements OnInit {
  user: any = {
    'loginId': null,
    'password': null
  };
  iscdac: any;
  auser: any = {
    'aloginId': null,
    'apassword': null
  };
  alert: any;
  constructor(private auth: AuthService, private myRoute: Router, private app: AppComponent, private service: LoginService) {
    sessionStorage.clear();
    this.user.loginId = null;
    this.user.password = null;
    this.auser.aloginId = null;
    this.auser.apassword = null;
    this.iscdac = this.app.iscdac;
    this.alert = this.app.alert;
  }

  ngOnInit() {
    $(".toggle-password").click(function () {

      $(this).toggleClass("fa-eye fa-eye-slash");
      var input = $($(this).attr("toggle"));
      if (input.attr("type") == "password") {
        input.attr("type", "text");
      } else {
        input.attr("type", "password");
      }
    });
  }

  login(type): any {

    try {
      var udata = {
        "loginId": this.user.loginId,
        "password": this.user.password,
        "requesttype": 2
      }
      this.service.login(udata).then(data => {
        if (data["status"] == 1 && data) {
          this.auth.setToken(data);
          console.log()
          if (data["RoleId"] == 1) {
            this.myRoute.navigate(["dashboard"]);
          } else {
            if (data["LoginStatus"] == 1) {
              var token = sessionStorage.getItem('jwttoken');
              this.service.getstoredquestions({
                tokendata: token
              }).then(data => {
                if (data && data["status"] == 1) {
                  console.log(data);
                  this.myRoute.navigate(["quiz"], data);
                }else{

                }

              })

            } else {

              this.myRoute.navigate(["information"]);
            }
          }
        } else {
          this.alert.color = 'warning';
          this.alert.message = data["message"];
          this.alert.status = -1;
          $('#lmessageModal').modal('show');
          setTimeout(() => {
            $('#lmessageModal').modal('hide');
          }, 2000)
        }


      }, err => {
        this.alert.color = 'danger';
        this.alert.message = this.app.errorMessage;
        this.alert.status = -1;
        $('#lmessageModal').modal('show');
        setTimeout(() => {
          $('#lmessageModal').modal('hide');
        }, 2000)
      })
    } catch (error) {
      this.alert.color = 'danger';
      this.alert.message = this.app.errorMessage;
      this.alert.status = -1;
      $('#lmessageModal').modal('show');
      setTimeout(() => {
        $('#lmessageModal').modal('hide');
      }, 2000)
    }
  }
}
