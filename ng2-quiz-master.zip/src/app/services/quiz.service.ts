import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppComponent } from '../app.component';

@Injectable()
export class QuizService {
  updateAnswer(rdata: any) {
    return this.http.post(this.app.url  + 'getaddstudentanswers',rdata,{headers:this.headers}).toPromise()
  }

  constructor(private http: HttpClient,private app:AppComponent) { 
    this.token = sessionStorage.getItem('jwttoken');
    this.headers = new HttpHeaders()
        .set('Authorization', this.token);
  }

  get(url: string) {
    return this.http.get(url);
  }

  getAll() {
    return [
      { id: 'data/javascript.json', name: 'JavaScript' },
      { id: 'data/aspnet.json', name: 'Asp.Net' },
      { id: 'data/csharp.json', name: 'C Sharp' },
      { id: 'data/designPatterns.json', name: 'Design Patterns' }
    ];
  }

  headers: HttpHeaders | { [header: string]: string | string[]; };
  token: string | string[];

  // constructor(private http:HttpClient,private app:AppComponent) { 
   
  // }

    getQuestions(qdata:any):any{
      return  this.http.post(this.app.url + 'getsectionwisequestions',qdata,{headers:this.headers}).toPromise();
    }

}
