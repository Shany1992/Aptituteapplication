import { Component, OnInit, HostListener } from '@angular/core';

import { QuizService } from '../services/quiz.service';
import { HelperService } from '../services/helper.service';
import { Option, Question, Quiz, QuizConfig } from '../models/index';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { AppComponent } from '../app.component';
declare var $: any;

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css'],
  providers: [QuizService]
})
export class QuizComponent implements OnInit {
  quizes: any[];
  quiz: Quiz = new Quiz(null);
  mode = 'quiz';
  quizName: string;
  timeTaken: null;
  config: QuizConfig = {
    'allowBack': true,
    'allowReview': true,
    'autoMove': false,  // if true, it will move to next question automatically when answered.
    'duration': 300,  // indicates the time (in secs) in which quiz needs to be completed. 0 means unlimited.
    'pageSize': 1,
    'requiredAll': false,  // indicates if you must answer all the questions before submitting.
    'richText': false,
    'shuffleQuestions': false,
    'shuffleOptions': true,
    'showClock': true,
    'showPager': true,
    'theme': 'bootstrap'
  };

  pager = {
    index: 0,
    size: 1,
    count: 1
  };
  timer: any = null;
  startTime: Date;
  endTime: Date;
  ellapsedTime = '00:00';
  duration = '';
  quizData: any;
  quizSelect: any;
  idname: any;
  sessionQuiz: any;
  sectionId: any;
  alert: any;


  constructor(private quizService: QuizService, private route: Router, private auth: AuthService, private app: AppComponent) {
    this.alert = this.app.alert;
    window.addEventListener("beforeunload", function (e) {
      var confirmationMessage = "\o/";
      console.log("cond");
      e.returnValue = confirmationMessage;     // Gecko, Trident, Chrome 34+
      return confirmationMessage;              // Gecko, WebKit, Chrome <34
    });
    const navigation = this.route.getCurrentNavigation();
    if (navigation.extras) {
      var keydata = Object.keys(navigation.extras);

      if (keydata[1] == "message" && keydata[0] == "status") {
        this.quizData = navigation.extras["message"];
        console.log("Hello " + this.quizData);
        // sessionStorage.setItem('qData',this.quizData)
        sessionStorage.setItem('quizData', JSON.stringify(this.quizData))
      } else if (keydata[0] == "replaceUrl") {

      }
    }

  }

  ngOnInit() {

    window.addEventListener("beforeunload", function (e) {
      var confirmationMessage = "\o/";
      e.returnValue = confirmationMessage;     // Gecko, Trident, Chrome 34+
      return confirmationMessage;              // Gecko, WebKit, Chrome <34
    });

    if (sessionStorage.getItem('quizData')) {
      this.sessionQuiz = JSON.parse(sessionStorage.getItem('quizData'));
      this.quizSelect = this.sessionQuiz.sections;
      if (this.quizSelect) {
        this.loadQuiz();
      } else {
        this.alert.color = 'danger';
        this.alert.message = this.app.errorMessage;
        this.alert.status = -1;
        $('#quizModal').modal('show');
        setTimeout(() => {
          $('#quizModal').modal('hide');
        }, 2000)
      }
    } else {
      this.alert.color = 'danger';
      this.alert.message = this.app.errorMessage;
      this.alert.status = -1;
      $('#quizModal').modal('show');
      setTimeout(() => {
        $('#quizModal').modal('hide');
      }, 2000)
    }

  }

  ngAfterViewInit(): void {

    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
    document.getElementById(this.idname).classList.add('active');
  }
  loadQuiz() {
    try {
      if (this.quizSelect && this.quizSelect[0] && this.quizSelect[0]["questionIds"]) {
        this.idname = this.quizSelect[0].sectionName;
        this.sectionId = this.quizSelect[0].sectionId;
        this.quizService.getQuestions({
          'questionid': this.quizSelect[0]["questionIds"],
          'testid': this.sessionQuiz.testid
        }).then(data => {
          this.quiz = new Quiz(data.question);
          if (this.quiz && this.quiz["questions"]) {
            for (let index = 0; index < this.quiz["questions"].length; index++) {
              const element = this.quiz["questions"][index];
              for (let qindex = 0; qindex < element.options.length; qindex++) {
                const qelement = element.options[qindex];
                this.onSelect(element, qelement, 1);
              }
            }
          }
          this.pager.count = this.quiz.questions.length;
          this.startTime = new Date();
          this.ellapsedTime = '00:00';
          this.timer = setInterval(() => { this.tick(); }, 1000);
          var timearr = parseInt(this.sessionQuiz.totalexamtime) * 60;

          this.duration = this.parseTime(timearr);
          this.mode = 'quiz';
        }, err => {
          this.alert.color = 'danger';
          this.alert.message = this.app.errorMessage;
          this.alert.status = -1;
          $('#quizModal').modal('show');
          setTimeout(() => {
            $('#quizModal').modal('hide');
          }, 2000)
        })

      } else {
        this.alert.color = 'danger';
        this.alert.message = this.app.errorMessage;
        this.alert.status = -1;
        $('#quizModal').modal('show');
        setTimeout(() => {
          $('#quizModal').modal('hide');
        }, 2000)
      }
    } catch (error) {
      this.alert.color = 'danger';
      this.alert.message = this.app.errorMessage;
      this.alert.status = -1;
      $('#quizModal').modal('show');
      setTimeout(() => {
        $('#quizModal').modal('hide');
      }, 2000)
    }

  }

  tick() {
    const now = new Date();

    const diff = (now.getTime() - this.startTime.getTime()) / 1000;
    if (diff >= this.config.duration) {
      // this.onSubmit(0, '');
    }
    this.ellapsedTime = this.parseTime(diff);
  }

  parseTime(totalSeconds: number) {
    let mins: string | number = Math.floor(totalSeconds / 60);
    let secs: string | number = Math.round(totalSeconds % 60);
    mins = (mins < 10 ? '0' : '') + mins;
    secs = (secs < 10 ? '0' : '') + secs;
    return `${mins}:${secs}`;
  }

  get filteredQuestions() {
    return (this.quiz.questions) ?
      this.quiz.questions.slice(this.pager.index, this.pager.index + this.pager.size) : [];
  }

  onSelect(question: Question, option: any, firstuse: any) {
    if (firstuse == 2) {
      if (question.questionTypeId === 1) {
        question.options.forEach((x) => {
          if (x.id !== option.id) {
            x.selected = false;
          }
        });
      }

      if (this.config.autoMove) {
        this.goTo(this.pager.index + 1, '');
      }
    } else {
      question.options.forEach((x) => {
        x.selected = x.isAnswer;
      })
    }
  }

  goTo(index: number, data: any) {
    // if (index == this.pager.count) {
    var selectedAnswer: null;
    if (data) {
      data.options.forEach(element => {
        if (element.selected == true) {
          selectedAnswer = element.id
        }
      });
      var requestData = {
        "testid": this.sessionQuiz.testid,
        "questiontypeid": data.questionTypeId,
        "questionid": data.id,
        "time": this.ellapsedTime,
        "sectionid": this.sectionId,
        "answer": selectedAnswer,
        "isfinalsubmit": 0
      }
      if (index >= 0 && index < this.pager.count) {
        try {

          this.quizService.updateAnswer(requestData).then(data => {
              if(data && data["status"] == 1){
                this.alert.color = 'success';
                this.alert.message = this.app.addMessage;
                this.alert.status = 1;
                $('#quizModal').modal('show');
                setTimeout(() => {
                  $('#quizModal').modal('hide');
                }, 2000)
              }else{
                this.alert.color = 'warning';
                this.alert.message = this.app.nodataMessage;
                this.alert.status = -1;
                $('#quizModal').modal('show');
                setTimeout(() => {
                  $('#quizModal').modal('hide');
                }, 2000)
              }
          }, err => {
            this.alert.color = 'danger';
            this.alert.message = this.app.errorMessage;
            this.alert.status = -1;
            $('#quizModal').modal('show');
            setTimeout(() => {
              $('#quizModal').modal('hide');
            }, 2000)
          })


        } catch (error) {

        }

        this.pager.index = index;
        this.mode = 'quiz';
      } else {
        try {

          this.quizService.updateAnswer(requestData).then(data => {
            console.log(data);
          }, err => {

          })


        } catch (error) {

        }
      }
    }

    // } else {
    // var selectedAnswer: null;
    // if (data) {
    //   data.options.forEach(element => {
    //     if (element.selected == true) {
    //       selectedAnswer = element.id
    //     }
    //   });
    //   var requestData = {
    //     "testid": this.sessionQuiz.testid,
    //     "questiontypeid": data.questionTypeId,
    //     "questionid": data.id,
    //     "time": this.ellapsedTime,
    //     "sectionid": this.sectionId,
    //     "answer": selectedAnswer,
    //     "isfinalsubmit": 0
    //   }
    //   if (index >= 0 && index < this.pager.count) {
    //     try {
    //       if (selectedAnswer) {
    //         this.quizService.updateAnswer(requestData).then(data => {
    //           //Add 'implements AfterViewInit' to the class.
    //           document.getElementById(this.quizSelect[0].sectionName).classList.remove('active');
    //           document.getElementById(this.quizSelect[1].sectionName).classList.add('active');
    //         }, err => {

    //         })
    //       }

    //     } catch (error) {

    //     }

    //     this.pager.index = index;
    //     this.mode = 'quiz';
    //   }
    // }
    // }


  }

  isAnswered(question: Question) {
    return question.options.find(x => x.selected) ? 'Answered' : 'Not Answered';
  };

  isCorrect(question: Question) {
    return question.options.every(x => x.selected === x.isAnswer) ? 'correct' : 'wrong';
  };

  onSubmit(index: number, data: any) {
    try {
      this.goTo(index, data);

      this.auth.logout();
    } catch (error) {

    }

    // $('#qlogout').modal('show');
    // this.route.navigate(["thankyou"]);
    // this.auth.logout();


    // let answers = [];
    // this.quiz.questions.forEach(x => answers.push({ 'quizId': this.quiz.id, 'questionId': x.id, 'answered': x.answered }));

    // // Post your data to the server here. answers contains the questionId and the users' answer.
    // console.log(this.quiz.questions);
    // this.mode = 'result';
  }

  confirm(): any {
    $('#qlogout').modal('hide');
    this.auth.logout();
  }
  getData(section) {
    this.pager.index = 0;
    try {
      this.idname = section.sectionName;
      this.sectionId = section.sectionId;
      if (this.idname) {
        this.quizService.getQuestions({
          'questionid': section.questionIds,
          'testid': this.sessionQuiz.testid
        }).then(data => {

          this.quiz = new Quiz(data.question);
          if (this.quiz && this.quiz["questions"]) {
            for (let index = 0; index < this.quiz["questions"].length; index++) {
              const element = this.quiz["questions"][index];
              for (let qindex = 0; qindex < element.options.length; qindex++) {
                const qelement = element.options[qindex];
                this.onSelect(element, qelement, 1);
              }
            }
          }
          this.quiz.id = this.sessionQuiz.testid;
          this.quiz.name = this.sessionQuiz.testname;
          this.quiz.description = this.sessionQuiz.description;

        }, err => {

        })
      } else {

      }
    } catch (error) {

    }

  }

  gotoQuestion(index: number, data: any) {

    if (index >= 0 && index < this.pager.count) {
      this.pager.index = index;
      this.mode = 'quiz';
    }
  }
}
