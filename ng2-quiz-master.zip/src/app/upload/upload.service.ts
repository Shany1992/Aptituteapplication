import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppComponent } from '../app.component';

@Injectable({
  providedIn: 'root'
})
export class UploadService {

  constructor(private http:HttpClient,private app:AppComponent) { }

  agentUpload(myformData) {

    var data = sessionStorage.getItem('jwttoken');
    const headers = new HttpHeaders()
        .set('Authorization', data);
    return this.http.post(this.app.url + "fileread", myformData, { headers: headers }).toPromise();
}
}
