import { Component, OnInit } from '@angular/core';
import { Quiz } from '../models';
import { QuizService } from '../services/quiz.service';
import { UploadService } from './upload.service';
import { SectionService } from '../section/section.service';
declare var $:any;
@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
  // providers: [
    
  // ]
})
export class UploadComponent implements OnInit {
  studentFile:any;
  documentFile:any;
  active:boolean=true;
  quiz: Quiz = new Quiz(null);
  questionsData: any;

  rowData: any = {};
  quizes: { id: string; name: string; }[];
  quizName: string;
  qform: any={
    sname:null
  };
  sectionData: any;
  sectionId:any;
  constructor(private quizService: QuizService,private service:UploadService,private sservice:SectionService) { 
    this.sectionId ="";
  }

  ngOnInit() {
    // this.active = true;
    // this.qform.sname =null;
    // this.quizes = this.quizService.getAll();
    // // debugger;
    // this.quizName = this.quizes[0].id;
    // this.loadQuiz(this.quizName);
    // this.getdata(this.quizName);
    this.getSectionDetails();
  }
  // getdata(quizName: string) {
  //   // data/javascript.json
  //   try {
  //     this.quizService.get(quizName).subscribe(res => {
  //       this.quiz = new Quiz(res);
  //       this.questionsData = this.quiz.questions;
  //       console.log(this.questionsData);
  //     }, err => {
  //       console.log(err);
  //     })
  //   } catch (error) {

  //   }

  // }


  // loadQuiz(quizName: string) {
  //   this.quizService.get(quizName).subscribe(res => {
  //     this.quiz = new Quiz(res);
  //     this.getdata(quizName);
     
  //   });
  // }


  // editData(rowdata: any): any {
  //   this.rowData = rowdata;

  // }
  // changeoption(answerData: any): any {
  //    this.questionsData.find(element => {
  //     if (element.id == answerData.questionId) {
  //       element.options.forEach(elementData => {
  //         if (elementData.id == answerData.id) {
  //           elementData.isAnswer = true;
  //         } else {
  //           elementData.isAnswer = false;
  //         }
  //       })
  //     }
  //   })
  // }

  // saveData():any{
  //   $('#exampleModal').modal('hide');
  //     this.getdata(this.quizName);
    
  // }

  public clientfileEvent($event) {
    const fileSelected: File = $event.target.files[0];
    var myformData = new FormData();
    var sessionId = sessionStorage.getItem('c2Vzc2lvbkl');
    // var date = _moment(this.uploadDate).format("YYYY-MM-DD").toString();
    myformData.append("sectionid", this.sectionId);
    myformData.append('file', fileSelected);
    // myformData.append('sectiondata', this.sectionId);
    this.service.agentUpload(myformData).then(data=>{
      if(data["status"]==1){
        alert("File upload successfully");
      }else{
        alert("Something went wrong");
      }
    })

  }


  getSectionDetails(){
    this.sservice.getSectionList().then(data =>{

      if (data["status"] == 1) {
        this.sectionData = data["data"];
        console.log(   this.sectionData );
      } else {
        
      }
     
    })
  }
}
