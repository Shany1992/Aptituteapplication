import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
// import { ChartsModule } from 'ng2-charts';
import { AppComponent } from './app.component';
import { QuizComponent } from './quiz/quiz.component';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { AppRoutingModule } from './app-routing.module';
import { NavComponent } from './nav/nav.component';
import { FooterComponent } from './footer/footer.component';
import { AdashboardComponent } from './adashboard/adashboard.component';
import { UploadComponent } from './upload/upload.component';
import { InformationComponent } from './information/information.component';
import { ThankyouComponent } from './thankyou/thankyou.component';
import { SnavComponent } from './snav/snav.component';
import { CenterComponent } from './center/center.component';
import { ExamComponent } from './exam/exam.component';
import { ChartsModule } from 'ng2-charts';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TestComponent } from './test/test.component';
import { CKEditorModule } from 'ckeditor4-angular';
import { MatPaginatorModule, MatSortModule, MatFormFieldModule, MatTableModule, MatIconModule} from '@angular/material';
import { CenterService } from './center/center.service';

import { InformationService } from './information/information.service';
import { QuizService } from './services/quiz.service';
import { UploadService } from './upload/upload.service';
import { SectionComponent } from './section/section.component';
import { SectionService } from './section/section.service';
import {MatSelectModule} from '@angular/material/select';
import { AuthGuard } from './auth.guard';
@NgModule({
  declarations: [
    AppComponent,
    QuizComponent,
    LoginComponent,
    NavComponent,
    FooterComponent,
    AdashboardComponent,
    UploadComponent,
    InformationComponent,
    ThankyouComponent,
    SnavComponent,
    CenterComponent,
    ExamComponent,
    TestComponent,
    SectionComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    ChartsModule,
    BrowserAnimationsModule,
    CKEditorModule,
    MatPaginatorModule, MatSortModule, MatFormFieldModule,
    MatTableModule,
    MatIconModule,
    MatSelectModule
  ],
  providers: [CenterService,AppComponent,InformationService,QuizService,UploadService,
    SectionService,AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
