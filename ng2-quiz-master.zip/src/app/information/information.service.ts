import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppComponent } from '../app.component';

@Injectable({
  providedIn: 'root'
})
export class InformationService {
  headers: HttpHeaders;
  token: string;

  constructor(private http:HttpClient,private app:AppComponent) { 
    this.token = sessionStorage.getItem('jwttoken');
    this.headers = new HttpHeaders()
        .set('Authorization', this.token);
  }

  addupdateuser(userdata):any{
  return  this.http.post(this.app.url+ 'addupdateuser',userdata,{
      headers:this.headers
    }).toPromise();
  }
}
