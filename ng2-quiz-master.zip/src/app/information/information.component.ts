import { Component, OnInit, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { CenterService } from '../center/center.service';
import { FormGroup } from '@angular/forms';
import { InformationService } from './information.service';
import { AppComponent } from '../app.component';
declare var $: any;

@Component({
  selector: 'app-information',
  templateUrl: './information.component.html',
  styleUrls: ['./information.component.css']
})
export class InformationComponent implements OnInit {
  sform: any = {
    'uid': 0,
    'fname': null,
    'lname': null,
    'uname': null,
    'email': null,
    'cnumber': null,
    'password': null,
    'cpassword': null,
    'cname': null
  }
  centerData: any;
  alert: any;
  constructor(private myRoute: Router, private service: CenterService, private iservice: InformationService, private app: AppComponent) {
    this.getData();
    this.alert = this.app.alert;
    window.addEventListener("backbutton", function (e) {
      var confirmationMessage = "Hello how are you?";
      console.log("Hello" + e);
     // e.returnValue = confirmationMessage;     // Gecko, Trident, Chrome 34+
      return confirmationMessage;              // Gecko, WebKit, Chrome <34
    });
  }

 
  getData() {
    this.sform.cname = null;
    this.sform.uname = (sessionStorage.getItem('username') == 'null') ? '' : sessionStorage.getItem('username');

    this.sform.roleid = (sessionStorage.getItem('roleid') == 'null') ? '' : sessionStorage.getItem('roleid');;
    this.sform.fname = (sessionStorage.getItem('firstname') == 'null') ? '' : sessionStorage.getItem('firstname');;
    this.sform.lname = (sessionStorage.getItem('lastname') == 'null') ? '' : sessionStorage.getItem('lastname');
    this.sform.cnumber = (sessionStorage.getItem('mobilenumber') == 'null') ? '' : sessionStorage.getItem('mobilenumber');;
    this.sform.email = (sessionStorage.getItem('emailid') == 'null') ? '' : sessionStorage.getItem('emailid');
    this.sform.uid = (sessionStorage.getItem('userid') == 'null') ? '' : sessionStorage.getItem('userid');

    this.sform.cname = (sessionStorage.getItem('centerid') == 'null') ? '' : sessionStorage.getItem('centerid');
  }

  ngOnInit() {
    window.addEventListener("backbutton", function (e) {
      var confirmationMessage = "Hello how are you?";
      console.log("Hello" + e);
     // e.returnValue = confirmationMessage;     // Gecko, Trident, Chrome 34+
      return confirmationMessage;              // Gecko, WebKit, Chrome <34
    });
    // $('#messageModal').modal('show');
    // this.alert.message ="hello"
    // this.alert.color = "success";
    $(".toggle-password").click(function () {

      $(this).toggleClass("fa-eye fa-eye-slash");
      var input = $($(this).attr("toggle"));
      if (input.attr("type") == "password") {
        input.attr("type", "text");
      } else {
        input.attr("type", "password");
      }
    });
    this.getCenterList();
  }

  startTest() {
    try {

      if (this.sform.fname && this.sform.lname && this.sform.uname && this.sform.email && this.sform.cnumber && this.sform.password && this.sform.cpassword && this.sform.uid) {
        this.iservice.addupdateuser(this.sform).then(data => {
          if (data && data["status"] == 1) {
            console.log(data);
            this.alert.color = 'success';
            this.alert.message = this.app.addMessage;
            this.alert.status = 1;
            $('#messageModal').modal('show');
            setTimeout(() => {
              $('#messageModal').modal('hide');
              this.myRoute.navigate(["quiz"], data);
            }, 2000);
          } else {
            this.alert.color = 'danger';
            this.alert.message = this.app.errorMessage;
            this.alert.status = -1;
            $('#messageModal').modal('show');
            setTimeout(() => {
              $('#messageModal').modal('hide');
            }, 2000)
          }
        }, err => {
          this.alert.color = 'danger';
          this.alert.message = this.app.errorMessage;
          this.alert.status = -1;
          $('#messageModal').modal('show');
          setTimeout(() => {
            $('#messageModal').modal('hide');
          }, 2000)
        })
      } else {
        this.alert.color = 'danger';
        this.alert.message = this.app.errorMessage;
        this.alert.status = -1;
        $('#messageModal').modal('show');
        setTimeout(() => {
          $('#messageModal').modal('hide');
        }, 2000)
      }
    } catch (error) {
      this.alert.color = 'danger';
      this.alert.message = this.app.errorMessage;
      this.alert.status = -1;
      $('#messageModal').modal('show');
      setTimeout(() => {
        $('#messageModal').modal('hide');
      }, 2000)
    }



  }

  getCenterList(): any {
    try {
      this.service.getdata().then(data => {
        if (data && data["status"] == 1) {
          if (data["data"]) {
            this.centerData = data["data"];
          } else {
            this.alert.color = 'warning';
            this.alert.message = this.app.nodataMessage;
            this.alert.status = -1;
            $('#messageModal').modal('show');
            setTimeout(() => {
              $('#messageModal').modal('hide');
            }, 2000)
          }
        } else {
          this.alert.color = 'danger';
          this.alert.message = this.app.errorMessage;
          this.alert.status = -1;
          $('#messageModal').modal('show');
          setTimeout(() => {
            $('#messageModal').modal('hide');
          }, 2000)
        }
      }, err => {
        this.alert.color = 'danger';
        this.alert.message = this.app.errorMessage;
        this.alert.status = -1;
        $('#messageModal').modal('show');
        setTimeout(() => {
          $('#messageModal').modal('hide');
        }, 2000)

      })
    } catch (error) {
      this.alert.color = 'danger';
      this.alert.message = this.app.errorMessage;
      this.alert.status = -1;
      $('#messageModal').modal('show');
      setTimeout(() => {
        $('#messageModal').modal('hide');
      }, 2000)
    }
  }

}
