import { Component, OnInit } from '@angular/core';
import { AuthGuard } from '../auth.guard';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {
  type: string;

  constructor(public auth:AuthService) { }

  ngOnInit() {
    this.type = sessionStorage.getItem('type');
  }
  

}
