import { Component, OnInit, HostListener } from '@angular/core';
import { CenterService } from './center.service';
import { MatTableDataSource } from '@angular/material';
declare var $:any;
@Component({
  selector: 'app-center',
  templateUrl: './center.component.html',
  styleUrls: ['./center.component.css']
})
export class CenterComponent implements OnInit {
  cform: any = {
    'ccode': null,
    'cname': null,
    'caddress': null,
    'cnumber': null,
    'cperson': null,
  }
  eform: any = {
    'sCenterCode': null,
    'sContactPerson': null,
    'sContactNumber': null,
    'sCenterAddress': null,
    'sCenterName': null,
    'nCenterId':null,
    'bIsActive':null
  };
  dataSource: any;
  constructor(private service: CenterService) { }
  @HostListener('window:popstate', ['$event'])
  onPopState(event) {
    console.log('Back button pressed');
  }

  getdata() {
    try {
      this.service.getdata().then(data => {
        this.dataSource = new MatTableDataSource(data["data"]);
      }, err => {
        console.log(err);
      })
    } catch (err) {
      console.log(err);

    }
  }

  geteditData(rowData: any) {
    try {
      this.eform = rowData;
    } catch (error) {

    }
  }

  save(type){
    try {
      if(type == 1){
        this.service.updateData(this.cform,type).then(data=>{
          
          if(data["status"]==1){
            this.closeAddModal();
            this.getdata();
            
          }else{
            this.closeAddModal();
            this.getdata();
          }
      },err=>{

      })
      }else if(type==2){
        this.service.updateData(this.eform,type).then(data=>{
            if(data["status"]==1){
              this.closeEditModal();
              this.getdata();
            }else{
              this.closeEditModal();
              this.getdata();
            }
        },err=>{

        })
      }
    } catch (err) {
      
    }

  }

  ngOnInit():any{
    this.getdata();
    this.getDetails();
  }

  closeAddModal(){
      
    $('#addcenter').modal('hide');
  }

  closeEditModal(){
      
    $('#editcenter').modal('hide');
  }

  getDetails(){
    this.service.getDetails().then(data=>{
      console.log(data);
    })
  }


}
