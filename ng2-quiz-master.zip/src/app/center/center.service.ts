import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppComponent } from '../app.component';

@Injectable({
  providedIn: 'root'
})
export class CenterService {
  updateData(eform: any,type:any) {
    var dform :any;
    if(type==1){
      dform = {
        'CenterId':0,
        'CenterCode':eform.ccode,
        'CenterName':eform.cname,
        'CenterAddress':eform.caddress,
        'ContactPerson':eform.cperson,
        'ContactNumber':eform.cnumber,
        // 'IsActive':eform.bIsActive.data[0],
        // 'CreatedBy': sessionStorage.getItem('UserId')
       }
    }else{
      dform = {
        'CenterId':eform.nCenterId,
        'CenterCode':eform.sCenterCode,
        'CenterName':eform.sCenterName,
        'CenterAddress':eform.sCenterAddress,
        'ContactPerson':eform.sContactPerson,
        'ContactNumber':eform.sContactNumber,
        'IsActive':eform.bIsActive.data[0],
        'CreatedBy': sessionStorage.getItem('UserId')
       }
    }
  
 
    return this.http.post(this.app.url + 'addupdatecenter',dform,{
      headers:this.headers
    }).toPromise();
  }
  token: string;
  headers: HttpHeaders;

  
  getdata() {
    return this.http.get(this.app.url + 'getcenterlist',{
      headers:this.headers
    }).toPromise();
  }

  getDetails(){
    return this.http.post(this.app.url + 'getsectionwisequestions',{"questionid":"1030,1018,1044,1019,1010,1024,1038,1042,1040,1031,1014,1012,1026,1046,1025,1016,1039,1033,1015,1004","testid":9},{
      headers:this.headers
    }).toPromise();
  }

  constructor(private http:HttpClient,private app:AppComponent) { 
    this.token = sessionStorage.getItem('jwttoken');
    this.headers = new HttpHeaders()
        .set('Authorization', this.token);
  }
}
