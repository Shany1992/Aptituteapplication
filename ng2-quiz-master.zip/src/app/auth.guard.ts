import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild, CanLoad, Route, UrlSegment, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
import { PRIMARY_OUTLET } from "@angular/router";
@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private auth: AuthService,
    private myRoute: Router){
  }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      if(this.auth.isLoggedIn() && this.myRoute.url !="/thankyou" ){
        // console.log();
        return true;
      }else{
        this.myRoute.navigate(["login"]);
        return false;
      }
  }
  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot,
    routerStateSnapshot: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      // if ( this.isPageRefresh() ) {

      //   console.warn( "Secondary view not allowed on refresh." );
      //   // this.myRoute.navigateByUrl( this.getUrlWithoutSecondary( routerStateSnapshot ) );
      //   return( false );
  
      // }
  
      return( true );
  }

  private getUrlWithoutSecondary( routerStateSnapshot: RouterStateSnapshot ) : UrlTree {

		var urlTree = this.myRoute.parseUrl( routerStateSnapshot.url );
		var segment = urlTree.root;

		// Since the "secondary" outlet is known to be directly off the primary view
		// (ie, not nested within another named-outlet), we're going to walk down the
		// tree of primary outlets and delete any "secondary" children. This should
		// leave us with a UrlTree that contains everything that the original URL had,
		// less the "secondary" named-outlet.
    // debugger;
    while ( segment && segment.children ) {

			delete( segment.children.secondary );

			segment = segment.children[ PRIMARY_OUTLET ];

		}

		return( urlTree );

	}
  canLoad(
    route: Route,
    segments: UrlSegment[]): Observable<boolean> | Promise<boolean> | boolean {
    return true;
  }

  // private isPageRefresh() : boolean {

	// 	// If the router has yet to establish a single navigation, it means that this
	// 	// navigation is the first attempt to reconcile the application state with the
	// 	// URL state. Meaning, this is a page refresh.
	// 	return( ! this.myRoute.navigated );

	// }
}
